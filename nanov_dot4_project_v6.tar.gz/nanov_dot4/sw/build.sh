#!/usr/bin/env bash
# Assemble a NanoV test program (RV32E + Zmmul) into a $readmemh word image
# of the PHYSICAL SPI memory contents (each byte bit-reversed, see below).
# usage: sw/build.sh prog.S out.mem
set -euo pipefail
src="$1"; out="$2"
tmp="$(mktemp -d)"
riscv64-unknown-elf-gcc -march=rv32e_zmmul -mabi=ilp32e -nostdlib -ffreestanding \
    -Wl,-melf32lriscv -Wl,-Ttext=0 -Wl,--no-relax -o "$tmp/p.elf" "$src"
riscv64-unknown-elf-objcopy -O binary "$tmp/p.elf" "$tmp/p.bin"
riscv64-unknown-elf-objdump -d -M no-aliases "$tmp/p.elf" > "${out%.mem}.lst"
python3 - "$tmp/p.bin" "$out" <<'PY'
import sys, struct
b = open(sys.argv[1], 'rb').read()
b += b'\0' * (-len(b) % 4)
# NanoV consumes the SPI stream LSB-first while a standard SPI memory (and
# upstream's sim_spi_ram) serves each byte MSB-first, so the physical memory
# image holds every byte bit-reversed.  Reverse here so the image is directly
# loadable into the SPI RAM model / FRAM.
b = bytes(int('{:08b}'.format(x)[::-1], 2) for x in b)
with open(sys.argv[2], 'w') as f:
    for (w,) in struct.iter_unpack('<I', b):
        f.write('%08x\n' % w)
PY
rm -rf "$tmp"
echo "built $out ($(wc -l < "$out") words)"
