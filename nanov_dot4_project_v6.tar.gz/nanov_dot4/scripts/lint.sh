#!/usr/bin/env bash
# Verilator -Wall lint of every configuration. FAILS if any warning is attributed to a file written for this
# project (rtl/*.v, tt/src/tt_um_*.v, fpga/zedboard_*.v).  Warnings in unmodified upstream NanoV files are
# counted and listed but do not fail the check (those files must stay byte-identical to upstream).
set -uo pipefail
cd "$(dirname "$0")/.."
UP="rtl/upstream/alu.v rtl/upstream/core.v rtl/upstream/cpu.v rtl/upstream/register.v rtl/upstream/shift.v rtl/upstream/multiply.v"
NEW="rtl/dot4_accel.v rtl/nanov_mmio_decoder.v rtl/nanov_dot4_soc.v"
mkdir -p reports; : > reports/lint.txt
rc=0
lint() {  # name top extra-files... -- verilator args
  local name=$1 top=$2; shift 2
  local out; out=$(verilator --lint-only -Wall -DSIMPLE_MULTIPLY --top-module "$top" "$@" 2>&1)
  local mine up
  mine=$(printf '%s\n' "$out" | grep -E '^%(Warning|Error)' | grep -E '(rtl/(dot4_accel|nanov_mmio_decoder|nanov_dot4_soc)\.v|tt_um_|zedboard_nanov|fpga/spi_mem_bram|fpga/board_spi_mem)' || true)
  up=$(printf '%s\n' "$out" | grep -E '^%(Warning|Error)' | grep -E 'rtl/upstream/' | wc -l)
  # real errors only (Verilator's "Exiting due to N warning(s)" summary is not an error of its own)
  if printf '%s\n' "$out" | grep -E '^%Error' | grep -v 'Exiting due to' | grep -q .; then
    echo "$name: ERROR"; printf '%s\n' "$out" | grep -E '^%Error' | grep -v 'Exiting due to' | head -5; rc=1; fi
  if [ -n "$mine" ]; then echo "$name: FAIL (warnings in project files)"; printf '%s\n' "$mine"; rc=1
  else echo "$name: PASS (0 warnings in project files; $up warnings in unmodified upstream files)"; fi
  { echo "== $name"; printf '%s\n' "$out" | grep -E '^%(Warning|Error)'; } >> reports/lint.txt
}
lint "soc ENABLE_DOT4=1 SHARED=1" nanov_dot4_soc -GDOT4_SHARED=1 -GENABLE_DOT4=1 $UP $NEW
lint "soc ENABLE_DOT4=1 SHARED=0" nanov_dot4_soc -GDOT4_SHARED=0 -GENABLE_DOT4=1 $UP $NEW
lint "soc ENABLE_DOT4=0"          nanov_dot4_soc -GENABLE_DOT4=0 $UP $NEW
lint "tt_um_nanov_dot4_accel"     tt_um_nanov_dot4_accel $UP $NEW tt/src/tt_um_nanov_dot4_accel.v
MEM="fpga/spi_mem_bram.v fpga/board_spi_mem.v"
lint "zedboard top INTERNAL_MEM=1 (stub UNISIM)" zedboard_nanov_dot4_top $UP $NEW $MEM fpga/zedboard_nanov_dot4_top.v fpga/sim/unisim_stubs.v
lint "zedboard top INTERNAL_MEM=0 (stub UNISIM)" zedboard_nanov_dot4_top -GINTERNAL_MEM=0 $UP $NEW $MEM fpga/zedboard_nanov_dot4_top.v fpga/sim/unisim_stubs.v
lint "spi_mem_bram (14-bit)" spi_mem_bram $MEM
exit $rc
