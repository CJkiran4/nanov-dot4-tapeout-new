#!/usr/bin/env bash
# Build + run all self-checking testbenches with Icarus Verilog.
# usage: scripts/run_sim.sh [RTL_ROOT]   (default: ./rtl, override to test a mutated copy)
# Exit status is non-zero unless every testbench prints exactly "RESULT: PASS".
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RTL="${1:-$ROOT/rtl}"
UP="$ROOT/rtl/upstream"          # upstream CPU files are never mutated
REF="$ROOT/ref_upstream"
OUT="$ROOT/build"; mkdir -p "$OUT"
cd "$ROOT"

CPU="$UP/alu.v $UP/core.v $UP/cpu.v $UP/register.v $UP/shift.v $UP/multiply.v"
NEW="$RTL/dot4_accel.v $RTL/nanov_mmio_decoder.v $RTL/nanov_dot4_soc.v"
IVL="iverilog -g2012 -Wall -DSIMPLE_MULTIPLY"
fail=0

run() {   # name, vvp, [-- logfile]
  local name="$1" vvp="$2"
  local log="$OUT/$name.log"
  vvp "$vvp" > "$log" 2>&1
  local pass; pass=$(grep -c '^RESULT: PASS$' "$log" || true)
  local bad;  bad=$(grep -c '^RESULT: FAIL$\|^FAIL' "$log" || true)
  if [ "$pass" -eq 1 ] && [ "$bad" -eq 0 ]; then
    printf '%-34s PASS   (%s)\n' "$name" "$(grep -E 'checks=|compared|LSB-first' "$log" | tail -1)"
  else
    printf '%-34s FAIL   (see %s)\n' "$name" "$log"; fail=1
  fi
}
build() { # name, iverilog args...
  local name="$1"; shift
  if ! $IVL -o "$OUT/$name.vvp" "$@" > "$OUT/$name.compile.log" 2>&1; then
    printf '%-34s FAIL   (compile error, see %s)\n' "$name" "$OUT/$name.compile.log"; fail=1; return 1
  fi
  return 0
}

build tb_spi_protocol -s tb_spi_protocol sim/tb_spi_protocol.v $CPU && run tb_spi_protocol "$OUT/tb_spi_protocol.vvp"
build tb_dot4_accel   -s tb_dot4_accel   sim/tb_dot4_accel.v $RTL/dot4_accel.v            && run tb_dot4_accel   "$OUT/tb_dot4_accel.vvp"
build tb_mmio_decoder -s tb_mmio_decoder sim/tb_mmio_decoder.v $RTL/nanov_mmio_decoder.v  && run tb_mmio_decoder "$OUT/tb_mmio_decoder.vvp"
build tb_nanov_baseline -s tb_nanov_baseline sim/tb_nanov_baseline.v sim/sim_spi_ram.v \
      $REF/top.v $REF/ledscan.v $REF/big_7seg.v $REF/musicnote.v $REF/uart_tx.v $REF/uart_rx.v $CPU $NEW \
      && run tb_nanov_baseline "$OUT/tb_nanov_baseline.vvp"
for sh in 1 0; do
  build tb_nanov_dot4_system_shared$sh -s tb_nanov_dot4_system -Ptb_nanov_dot4_system.SHARED=$sh \
      sim/tb_nanov_dot4_system.v sim/sim_spi_ram.v $CPU $NEW \
      && run tb_nanov_dot4_system_shared$sh "$OUT/tb_nanov_dot4_system_shared$sh.vvp"
done

# ---- on-chip SPI memory (FPGA board): same 80-vector system test on the synthesizable BRAM memory ----
for sh in 1 0; do
  build tb_nanov_dot4_system_bram_shared$sh -DUSE_BRAM_MEM -s tb_nanov_dot4_system -Ptb_nanov_dot4_system.SHARED=$sh \
      sim/tb_nanov_dot4_system.v fpga/spi_mem_bram.v $CPU $NEW \
      && run tb_nanov_dot4_system_bram_shared$sh "$OUT/tb_nanov_dot4_system_bram_shared$sh.vvp"
done
# ---- ZedBoard top with the demo program in block RAM: switches -> LEDs, both Dot4 architectures ----
BOARD="fpga/zedboard_nanov_dot4_top.v fpga/board_spi_mem.v fpga/spi_mem_bram.v fpga/sim/unisim_stubs.v $CPU $NEW"
for sh in 1 0; do
  build tb_board_demo_shared$sh -s tb_board_demo -Ptb_board_demo.SHARED=$sh sim/tb_board_demo.v $BOARD \
      && run tb_board_demo_shared$sh "$OUT/tb_board_demo_shared$sh.vvp"
done
exit $fail
