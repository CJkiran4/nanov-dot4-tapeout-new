#!/usr/bin/env bash
# Fault injection on fpga/spi_mem_bram.v.  Each mutant is a one-line sed on a scratch copy; the 80-vector system
# test (USE_BRAM_MEM) or the board demo test on that copy must FAIL.  A control run with an identity sed must PASS.
set -uo pipefail
cd "$(dirname "$0")/.."
T=$(mktemp -d); CPU="rtl/upstream/alu.v rtl/upstream/core.v rtl/upstream/cpu.v rtl/upstream/register.v rtl/upstream/shift.v rtl/upstream/multiply.v"
NEW="rtl/dot4_accel.v rtl/nanov_mmio_decoder.v rtl/nanov_dot4_soc.v"
killed=0; total=0
try() {  # name, sed-expression
  cp fpga/spi_mem_bram.v "$T/m.v"; sed -i "$2" "$T/m.v"
  if cmp -s fpga/spi_mem_bram.v "$T/m.v" && [ "$1" != "CTL" ]; then echo "$1: sed did not change the file"; return; fi
  iverilog -g2012 -DSIMPLE_MULTIPLY -DUSE_BRAM_MEM -s tb_nanov_dot4_system -Ptb_nanov_dot4_system.SHARED=1 \
      -o "$T/m.vvp" sim/tb_nanov_dot4_system.v "$T/m.v" $CPU $NEW > "$T/c.log" 2>&1 || { echo "$1: compile error"; return; }
  local res; res=$(timeout 300 vvp "$T/m.vvp" 2>&1 | grep -c '^RESULT: PASS$')
  # second test: the ZedBoard demo program (uses slli, i.e. multi-cycle instructions that pause the SPI clock)
  if [ "$res" = 1 ]; then
    iverilog -g2012 -DSIMPLE_MULTIPLY -s tb_board_demo -o "$T/b.vvp" sim/tb_board_demo.v fpga/zedboard_nanov_dot4_top.v \
        fpga/board_spi_mem.v "$T/m.v" fpga/sim/unisim_stubs.v $CPU $NEW > "$T/cb.log" 2>&1 || { echo "$1: board compile error"; return; }
    res=$(timeout 300 vvp "$T/b.vvp" 2>&1 | grep -c '^RESULT: PASS$')
  fi
  total=$((total+1))
  if [ "$1" = "CTL" ]; then [ "$res" = 1 ] && echo "CTL: passes as expected" || echo "CTL: UNEXPECTED FAIL"
  else [ "$res" = 0 ] && { echo "$1: killed"; killed=$((killed+1)); } || echo "$1: SURVIVED"; fi
}
try CTL  's/xxxxxxxx/yyyyyyyy/'
try MB1  's/cnt_n == 6.d32/cnt_n == 6'"'"'d31/'
try MB2  's/dout\[{addr\[4:3\], ~addr\[2:0\]}\]/dout[{addr[4:3], addr[2:0]}]/'
try MB3  's/bw_lane <= addr\[4:3\];/bw_lane <= addr[4:3] ^ 2'"'"'b01;/'
try MB4  's/wire \[ADDR_WORD_BITS-1:0\] ra = addr_n\[/wire [ADDR_WORD_BITS-1:0] ra = addr[/'
try MB5  's/if (r_sel) begin/if (1'"'"'b0) begin/'
try MB6  's/if (addr\[2:0\] == 3.d7) bw_en_n/if (addr[2:0] == 3'"'"'d6) bw_en_n/'
try MB7  's/bw_data <= {wsh\[6:0\], r_mosi};/bw_data <= {r_mosi, wsh[6:0]};/'
try MB8  's/cmd_n\[31:24\] == 8.h03) reading_n/cmd_n[31:24] == 8'"'"'h04) reading_n/'
try MB9  's/if (we\[2\]) data\[bw_addr\]\[23:16\] <= wd\[23:16\];//'
try MB10 's/bw_addr <= addr\[ADDR_WORD_BITS+4:5\];/bw_addr <= addr_n[ADDR_WORD_BITS+4:5];/'
try MB11 's/r_ev   <= spi_clk_en;/r_ev   <= 1'"'"'b1;/'
echo "spi_mem_bram mutants: $killed killed of $((total-1))"
rm -rf "$T"
