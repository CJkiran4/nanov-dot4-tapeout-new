#!/usr/bin/env bash
# Mutation sanity check: inject single bugs into a COPY of the new RTL and verify
# that scripts/run_sim.sh reports at least one failing testbench for each.
# A mutant that still passes means the testbenches have a coverage hole.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
mut() {  # id, file, python-regex-old, new, description
  if [ -n "$ONLY" ] && ! echo " $ONLY " | grep -q " $1 "; then return; fi
  local id="$1" file="$2" old="$3" new="$4" desc="$5"
  rm -rf "$TMP/rtl"; mkdir -p "$TMP/rtl"; cp "$ROOT"/rtl/*.v "$TMP/rtl/"
  python3 - "$TMP/rtl/$file" "$old" "$new" <<'PY'
import sys,re
p,old,new=sys.argv[1:4]
s=open(p).read()
n=s.count(old)
if n==0: print("MUTATION-NOT-APPLIED"); sys.exit(3)
open(p,'w').write(s.replace(old,new,1))
PY
  [ $? -eq 3 ] && { printf '%-4s %-52s NOT APPLIED\n' "$id" "$desc"; return; }
  out="$("$ROOT/scripts/run_sim.sh" "$TMP/rtl" 2>&1)"
  nfail=$(printf '%s\n' "$out" | grep -c ' FAIL ')
  if [ "$id" = "CTL" ]; then      # control: a comment-only change must NOT be detected
    if [ "$nfail" -eq 0 ]; then printf '%-4s %-52s OK (survived, as required of a control)\n' "$id" "$desc"
    else printf '%-4s %-52s BAD CONTROL (regression is flaky)\n' "$id" "$desc"; SURV=1; fi
  elif [ "$nfail" -gt 0 ]; then
    printf '%-4s %-52s KILLED   (%s)\n' "$id" "$desc" "$(printf '%s\n' "$out" | grep ' FAIL ' | awk '{print $1}' | paste -sd, -)"
    KILLED=$((KILLED+1))
  else
    printf '%-4s %-52s SURVIVED (testbench hole!)\n' "$id" "$desc"; SURV=1; SURVIVORS=$((SURVIVORS+1))
  fi
  TOTAL=$((TOTAL+1))
}
SURV=0; KILLED=0; SURVIVORS=0; TOTAL=0; ONLY="${MUT_ONLY:-}"
mut M1  dot4_accel.v "wire signed [7:0]  ma   = a_r[7:0];"  "wire [7:0] ma = a_r[7:0];" "shared: unsigned operand A"
mut M2  dot4_accel.v "wire signed [15:0] p1 = a1 * b1;"     "wire signed [15:0] p1 = a1 * b0;" "parallel: wrong lane pairing"
mut M3  dot4_accel.v "if (!acc_en) acc <= 32'd0;"           "" "shared: acc not cleared on non-accumulating start"
mut M4  dot4_accel.v "a_r <= {a_r[7:0], a_r[31:8]};"        "a_r <= {8'd0, a_r[31:8]};" "shared: operand A shifted instead of rotated"
mut M5  dot4_accel.v "cnt == 2'd3"                          "cnt == 2'd2" "shared: finishes one cycle early"
mut M6  dot4_accel.v "end else if (busy_r) begin
                    acc    <= acc + sum;" "end else if (busy_r) begin
                    acc    <= acc - sum;" "parallel: subtracts instead of adds"
mut M7  dot4_accel.v "acc <= acc + {{16{prod[15]}}, prod};" "acc <= acc + {16'd0, prod};" "shared: product not sign-extended into acc"
mut M8  dot4_accel.v "                    if (wr_a) a_r <= wdata;
                    if (wr_b) b_r <= wdata;
                    if (clr) begin
                        acc    <= 32'd0;
                        done_r <= 1'b0;
                    end
                    if (start) begin
                        busy_r <= 1'b1;
                        done_r <= 1'b0;
                        cnt " "                    if (wr_a) a_r <= wdata;
                    if (wr_b) b_r <= wdata;
                    if (clr) begin
                        acc    <= 32'd0;
                    end
                    if (start) begin
                        busy_r <= 1'b1;
                        done_r <= 1'b0;
                        cnt " "shared: clr does not clear done"
mut M9  nanov_mmio_decoder.v "addr == 32'h10000004" "addr == 32'h10000008" "decoder: GPIO_IN at wrong address"
mut M10 nanov_mmio_decoder.v "addr == 32'h10000100" "addr[30:0] == 31'h10000100" "decoder: DOT_A aliases with bit 31 set"
mut M11 nanov_mmio_decoder.v "assign dot_clr   = (ENABLE_DOT4 != 0) && wr_ctrl && wdata[2];" "assign dot_clr   = (ENABLE_DOT4 != 0) && wr_ctrl && wdata[1];" "decoder: CLR decoded from wrong bit"
mut M12 nanov_mmio_decoder.v "gpio_out <= wdata[7:0];" "gpio_out <= wdata[8:1];" "decoder: GPIO_OUT captures wrong bits"
mut M13 nanov_mmio_decoder.v "PERI_DOT_CTRL: rd = (ENABLE_DOT4 != 0) ? {30'd0, dot_done, dot_busy} : 32'd0;" "PERI_DOT_CTRL: rd = (ENABLE_DOT4 != 0) ? {30'd0, dot_busy, dot_done} : 32'd0;" "decoder: BUSY/DONE swapped on read"
mut M14 nanov_dot4_soc.v "assign spi_clk_out = !clk && spi_clk_enable;" "assign spi_clk_out = clk && spi_clk_enable;" "soc: SPI clock polarity inverted"
mut M15 nanov_dot4_soc.v "spi_mosi <= spi_data_out;" "spi_mosi <= spi_select_out;" "soc: MOSI wired to wrong signal"
mut M16 nanov_mmio_decoder.v "else if (data_valid && sel == PERI_GPIO_OUT)" "else if (data_valid)" "decoder: any write updates GPIO_OUT"
mut M17 dot4_accel.v "                        busy_r <= 1'b0;
                        done_r <= 1'b1;
                    end
                end else begin" "                        busy_r <= 1'b0;
                    end
                end else begin" "shared: DONE never asserted (hang -> TB timeout path)"
mut M18 nanov_mmio_decoder.v "PERI_DOT_RES:  rd = (ENABLE_DOT4 != 0) ? dot_result : 32'd0;" "PERI_DOT_RES:  rd = (ENABLE_DOT4 != 0) ? dot_a_rd : 32'd0;" "decoder: DOT_RESULT read returns operand A"
mut M19 nanov_dot4_soc.v "buffered_spi_in <= spi_miso;" "buffered_spi_in <= ~spi_miso;" "soc: SPI MISO inverted into CPU"
mut M20 nanov_dot4_soc.v "spi_mosi <= spi_data_out;" "spi_mosi <= spi_data_out & ~(spi_select_out);" "soc: MOSI forced low while deselected (pin-level only)"
mut M21 nanov_mmio_decoder.v "assign dot_start = (ENABLE_DOT4 != 0) && wr_ctrl && wdata[0];" "assign dot_start = (ENABLE_DOT4 != 0) && wr_ctrl;" "decoder: any CTRL write starts (START bit ignored)"
mut CTL dot4_accel.v "// INT8 Dot4 accelerator." "// INT8 Dot4 accelerator. (comment-only control mutant)" "control: comment-only edit (expected SURVIVED)"
rm -rf "$TMP"
echo "mutants evaluated (incl. control): $TOTAL, killed: $KILLED, survived: $SURVIVORS"
[ "$SURV" -eq 0 ] && echo "ALL MUTANTS KILLED, CONTROL BEHAVED" || { echo "MUTATION CHECK FAILED"; exit 1; }
