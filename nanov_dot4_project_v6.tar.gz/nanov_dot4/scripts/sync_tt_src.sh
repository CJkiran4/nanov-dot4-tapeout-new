#!/usr/bin/env bash
# Copy the RTL into tt/src (Tiny Tapeout requires sources under ./src) and verify they match.
set -euo pipefail
cd "$(dirname "$0")/.."
for f in alu core cpu register shift multiply; do cp rtl/upstream/$f.v tt/src/$f.v; done
for f in dot4_accel nanov_mmio_decoder nanov_dot4_soc; do cp rtl/$f.v tt/src/$f.v; done
for f in alu core cpu register shift multiply; do cmp rtl/upstream/$f.v tt/src/$f.v; cmp upstream/$f.v tt/src/$f.v; done
echo "tt/src synced; upstream files byte-identical to MichaelBell/nanoV e1a405e"
