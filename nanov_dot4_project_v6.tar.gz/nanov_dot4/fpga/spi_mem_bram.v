// On-chip SPI RAM for the FPGA board: block RAM behind the same SPI protocol that NanoV expects
// (sim/sim_spi_ram.v is the behavioural reference this module was written to match):
//   command 0x03 + 24-bit byte address -> read,  command 0x02 + address -> write, data MSB-first per byte.
//
// Why it exists: NanoV fetches EVERY instruction from SPI memory.  With no external SPI RAM on Pmod JA the
// bitstream alone would show nothing.  This module puts the program inside the FPGA so the board runs by itself.
//
// Clocking: everything is in the CPU clock domain (no derived clock).  The SoC's SPI clock is
// spi_clk = !clk & spi_clk_en, so
//   * an SPI rising  edge happens at the falling edge of clk when spi_clk_en = 1  -> MOSI / CS sampled at negedge,
//   * an SPI falling edge happens at the next rising edge of clk if spi_clk_en was 1.
// Both events are applied at that rising edge.  spi_clk_en, spi_select and spi_mosi are all registered in the clk
// domain by the SoC, so every path here is at most half a clock.
//
// Storage convention is identical to sim_spi_ram: the memory holds the PHYSICAL (bit-reversed per byte) image,
// bit (byte*8 + 7 - bit_in_byte) of word (addr>>2) is the bit served at SPI bit position `bit_in_byte`.
//
// Limitation (documented, not hit by NanoV): writes are stored per complete byte; a write transaction that ends
// inside a byte drops the partial byte (sim_spi_ram would keep the bits).  NanoV's sb/sh/sw always send whole bytes.
`default_nettype none

module spi_mem_bram #(
    parameter integer ADDR_WORD_BITS = 14,                       // 2**14 words = 64 KiB (same as sim_spi_ram)
    parameter integer IMG_WORDS      = 1,                        // number of initialised words
    parameter [32*IMG_WORDS-1:0] IMAGE = {32*IMG_WORDS{1'b0}}    // word i = IMAGE[32*i +: 32] (physical image)
) (
    input  wire clk,
    input  wire spi_select,      // active low chip select (registered in the clk domain by the SoC)
    input  wire spi_mosi,        // registered in the clk domain by the SoC
    input  wire spi_clk_en,      // SoC's SPI clock enable
    output wire spi_miso
);
    localparam integer WORDS = 1 << ADDR_WORD_BITS;

    // ---- storage (name `data` kept so testbenches can use the same hierarchical access as sim_spi_ram) ----
    (* ram_style = "block" *) reg [31:0] data [0:WORDS-1];
    integer ii;
    initial begin
        for (ii = 0; ii < IMG_WORDS; ii = ii + 1) data[ii] = IMAGE[32*ii +: 32];
        for (ii = IMG_WORDS; ii < WORDS; ii = ii + 1) data[ii] = 32'd0;
    end

    // ---- sample the SPI rising-edge event at the falling edge of clk ----
    reg r_ev = 1'b0, r_sel = 1'b1, r_mosi = 1'b0;
    always @(negedge clk) begin
        r_ev   <= spi_clk_en;
        r_sel  <= spi_select;
        r_mosi <= spi_mosi;
    end

    // ---- protocol state (names follow sim_spi_ram) ----
    reg [31:0] cmd         = 32'd0;
    reg [26:0] addr        = 27'd0;
    reg [5:0]  start_count = 6'd0;
    reg        reading     = 1'b0;
    reg        writing     = 1'b0;
    reg        error       = 1'b0;
    reg [6:0]  wsh         = 7'd0;      // bits of the byte being written

    reg [31:0] cmd_n;
    reg [26:0] addr_n;
    reg [5:0]  cnt_n;
    reg        reading_n, writing_n, error_n;
    reg [6:0]  wsh_n;
    reg        bw_en_n;

    always @* begin
        cmd_n = cmd;  addr_n = addr;  cnt_n = start_count;
        reading_n = reading;  writing_n = writing;  error_n = error;
        wsh_n = wsh;  bw_en_n = 1'b0;
        if (r_sel) begin
            cmd_n = 32'd0;  addr_n = 27'd0;  cnt_n = 6'd0;
            reading_n = 1'b0;  writing_n = 1'b0;  error_n = 1'b0;
        end else if (r_ev) begin
            // SPI rising edge: count, shift the command in, or take a write bit
            cnt_n = start_count + 6'd1;
            if (writing) begin
                wsh_n = {wsh[5:0], r_mosi};
                if (addr[2:0] == 3'd7) bw_en_n = 1'b1;       // 8th bit of the byte: store it
            end else if (!reading && !error) begin
                cmd_n = {cmd[30:0], r_mosi};
            end
            // SPI falling edge: advance the address, or decode the command after 32 clocks
            if (reading || writing) begin
                addr_n = addr + 27'd1;
            end else if (!error && cnt_n == 6'd32) begin
                addr_n = {cmd_n[23:0], 3'b000};
                if      (cmd_n[31:24] == 8'h03) reading_n = 1'b1;
                else if (cmd_n[31:24] == 8'h02) writing_n = 1'b1;
                else                            error_n   = 1'b1;
            end
        end
    end

    // ---- write port registers (one clk after the 8th bit) ----
    reg        bw_en   = 1'b0;
    reg [ADDR_WORD_BITS-1:0] bw_addr = {ADDR_WORD_BITS{1'b0}};
    reg [1:0]  bw_lane = 2'd0;
    reg [7:0]  bw_data = 8'd0;

    // read address = word of the NEXT bit address, so `dout` already holds the right word when `addr` changes
    wire [ADDR_WORD_BITS-1:0] ra = addr_n[ADDR_WORD_BITS+4:5];
    reg  [31:0] dout = 32'd0;

    always @(posedge clk) begin
        cmd <= cmd_n;  addr <= addr_n;  start_count <= cnt_n;
        reading <= reading_n;  writing <= writing_n;  error <= error_n;
        wsh <= wsh_n;
        bw_en   <= bw_en_n;
        bw_addr <= addr[ADDR_WORD_BITS+4:5];
        bw_lane <= addr[4:3];
        bw_data <= {wsh[6:0], r_mosi};
    end

    wire [3:0]  we = {4{bw_en}} & (4'b0001 << bw_lane);
    wire [31:0] wd = {4{bw_data}};

    // single clocked block with byte write enables and a registered read -> infers a simple-dual-port block RAM
    always @(posedge clk) begin
        if (we[0]) data[bw_addr][7:0]   <= wd[7:0];
        if (we[1]) data[bw_addr][15:8]  <= wd[15:8];
        if (we[2]) data[bw_addr][23:16] <= wd[23:16];
        if (we[3]) data[bw_addr][31:24] <= wd[31:24];
        dout <= data[ra];
    end

    assign spi_miso = reading ? dout[{addr[4:3], ~addr[2:0]}] : 1'b0;

    wire _unused_ok = &{1'b0, addr[26:ADDR_WORD_BITS+5]};
endmodule

`default_nettype wire
