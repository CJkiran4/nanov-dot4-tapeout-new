# ONE script: sources -> synthesis -> implementation -> bitstream -> reports -> program the ZedBoard.
# Vivado 2024.1.  Use it from the GUI Tcl Console (project already open) or in batch:
#     source F:/nanov_dot4_project_v4/nanov_dot4/fpga/tcl/board_flow.tcl
#     vivado -mode batch -source fpga/tcl/board_flow.tcl [-tclargs noprogram]
# What it does (each step stops the script with an error message if it fails):
#   0  uses the open project, or creates <root>/build/vivado_board if none is open
#   1  adds any missing source file, sets SIMPLE_MULTIPLY + generics, top = zedboard_nanov_dot4_top, adds the XDC
#   2  resets and runs synth_1, then impl_1 through write_bitstream
#   3  writes timing / DRC / utilization / power reports to <root>/reports/vivado/ and CHECKS setup+hold slack
#   4  programs the board (fpga/tcl/program_board.tcl) unless "noprogram" is given
set _bf_dir  [file dirname [file normalize [info script]]]
set root     [file normalize [file join $_bf_dir .. ..]]
set top      zedboard_nanov_dot4_top
set part     xc7z020clg484-1
set jobs     4
set do_program 1
if {[info exists argv] && [lsearch -exact $argv noprogram] >= 0} { set do_program 0 }
set rpt_dir [file join $root reports vivado]
file mkdir $rpt_dir

proc bf_step {n msg} { puts "\n=== STEP $n: $msg ===" }
proc bf_need {f} { if {![file exists $f]} { error "missing file $f" } ; return $f }

# ---- 0. project -------------------------------------------------------------------------------------
bf_step 0 "project"
if {[llength [get_projects -quiet]] == 0} {
    set pdir [file join $root build vivado_board]
    file mkdir $pdir
    create_project -force zedboard_nanov_dot4_board $pdir -part $part
    puts "created project in $pdir"
} else {
    puts "using open project [current_project] ([get_property DIRECTORY [current_project]])"
}

# ---- 1. sources, defines, top, constraints -------------------------------------------------------------
bf_step 1 "sources / defines / constraints"
set rtl_files [list \
    [file join $root rtl upstream alu.v]      [file join $root rtl upstream core.v] \
    [file join $root rtl upstream cpu.v]      [file join $root rtl upstream register.v] \
    [file join $root rtl upstream shift.v]    [file join $root rtl upstream multiply.v] \
    [file join $root rtl dot4_accel.v]        [file join $root rtl nanov_mmio_decoder.v] \
    [file join $root rtl nanov_dot4_soc.v] \
    [file join $root fpga spi_mem_bram.v]     [file join $root fpga board_spi_mem.v] \
    [file join $root fpga zedboard_nanov_dot4_top.v]]
set have [list]
foreach f [get_files -quiet -of_objects [get_filesets sources_1]] { lappend have [string tolower [file tail $f]] }
set add [list]
foreach f $rtl_files {
    bf_need $f
    if {[lsearch -exact $have [string tolower [file tail $f]]] < 0} { lappend add $f }
}
if {[llength $add] > 0} {
    add_files -norecurse -fileset sources_1 $add
    puts "added: [lmap f $add {file tail $f}]"
} else { puts "all [llength $rtl_files] source files already in the project" }
# files that are in the project but live in an OLD folder (e.g. a previous v-folder) would silently be used - warn
foreach f [get_files -quiet -of_objects [get_filesets sources_1] *.v] {
    if {![string match "$root/*" [file normalize $f]]} { puts "WARNING: source outside $root : $f  (remove it if it is a stale copy)" }
}
# multiply.v needs SIMPLE_MULTIPLY (otherwise it instantiates the SKY130 cell sky130_fd_sc_hd__sdfxtp_1)
set_property verilog_define {SIMPLE_MULTIPLY} [get_filesets sources_1]
set_property generic {DOT4_SHARED=1 INTERNAL_MEM=1} [get_filesets sources_1]
set_property top $top [get_filesets sources_1]
update_compile_order -fileset sources_1

set xdc [bf_need [file join $root fpga zedboard_nanov_dot4.xdc]]
set have_x 0
foreach f [get_files -quiet -of_objects [get_filesets constrs_1]] { if {[file tail $f] eq "zedboard_nanov_dot4.xdc"} { set have_x 1 } }
if {!$have_x} { add_files -norecurse -fileset constrs_1 $xdc ; puts "added constraints [file tail $xdc]" }

# ---- 2. synthesis / implementation / bitstream ---------------------------------------------------------
proc bf_check_run {run} {
    set st [get_property STATUS [get_runs $run]]
    puts "run $run: $st"
    if {[get_property PROGRESS [get_runs $run]] ne "100%" || [string match -nocase "*error*" $st] || [string match -nocase "*fail*" $st]} {
        error "run $run did not complete ($st) - open the Messages / Log tab of that run"
    }
}
bf_step 2 "synthesis"
reset_run synth_1
launch_runs synth_1 -jobs $jobs
wait_on_run synth_1
bf_check_run synth_1

bf_step 2 "implementation + bitstream"
reset_run impl_1
launch_runs impl_1 -to_step write_bitstream -jobs $jobs
wait_on_run impl_1
bf_check_run impl_1

# ---- 3. reports and sign-off checks ----------------------------------------------------------------------
bf_step 3 "reports"
open_run impl_1
report_timing_summary -delay_type min_max -max_paths 10 -file [file join $rpt_dir timing_summary.rpt]
report_drc            -file [file join $rpt_dir drc.rpt]
report_utilization    -file [file join $rpt_dir utilization.rpt]
report_power          -file [file join $rpt_dir power.rpt]
report_clock_utilization -file [file join $rpt_dir clock_utilization.rpt]
set wns [get_property STATS.WNS [get_runs impl_1]]
set tns [get_property STATS.TNS [get_runs impl_1]]
set whs [get_property STATS.WHS [get_runs impl_1]]
set ths [get_property STATS.THS [get_runs impl_1]]
puts "setup  WNS=$wns ns  TNS=$tns ns"
puts "hold   WHS=$whs ns  THS=$ths ns"
puts "reports in $rpt_dir"
if {$wns < 0 || $whs < 0} { error "timing NOT met (WNS=$wns, WHS=$whs) - see $rpt_dir/timing_summary.rpt" }
set bit [lindex [glob -nocomplain -directory [get_property DIRECTORY [get_runs impl_1]] *.bit] 0]
if {$bit eq ""} { error "bitstream was not written" }
file copy -force $bit [file join $root build]
puts "bitstream: $bit  (copy in [file join $root build])"
puts "NOTE: I/O delay constraints are not set, so I/O timing is unchecked; DRC warnings (e.g. ZPS7-1 on a Zynq without PS7) are listed in drc.rpt."

# ---- 4. board -------------------------------------------------------------------------------------------------
if {$do_program} {
    bf_step 4 "program the ZedBoard"
    set argv [list $bit]
    source [file join $_bf_dir program_board.tcl]
} else {
    puts "\n(noprogram) bitstream ready: $bit"
}
puts "\nFLOW COMPLETE"
