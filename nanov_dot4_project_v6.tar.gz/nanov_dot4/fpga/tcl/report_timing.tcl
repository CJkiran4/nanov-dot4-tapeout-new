# vivado -mode batch -source fpga/tcl/report_timing.tcl           (needs a routed impl_1)
# Writes timing / clock / methodology reports and FAILS if setup or hold slack is negative or if the
# design has unconstrained endpoints on the system clock.
source [file join [file dirname [file normalize [info script]]] common.tcl]
require_version
open_existing_project
file mkdir $rpt_dir
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} { fail "impl_1 is not complete" }
open_run impl_1
report_timing_summary     -file [file join $rpt_dir timing_summary_final.rpt] -delay_type min_max -max_paths 20 -report_unconstrained
report_clocks             -file [file join $rpt_dir clocks_final.rpt]
report_clock_interaction  -file [file join $rpt_dir clock_interaction.rpt]
report_clock_networks     -file [file join $rpt_dir clock_networks.rpt]
report_methodology        -file [file join $rpt_dir methodology.rpt]
check_timing              -file [file join $rpt_dir check_timing_final.rpt]

set wns  [get_property SLACK [get_timing_paths -max_paths 1 -setup]]
set whs  [get_property SLACK [get_timing_paths -max_paths 1 -hold]]
puts "WNS (setup) = $wns ns   WHS (hold) = $whs ns"
if {$wns eq "" || $whs eq ""} { fail "could not read timing slack" }
if {$wns < 0 || $whs < 0} { fail "timing not met (WNS=$wns, WHS=$whs)" }
puts "Timing met on constrained paths (unconstrained I/O paths are listed in timing_summary_final.rpt)."
close_project
