# vivado -mode batch -source fpga/tcl/program_fpga.tcl [-tclargs <bitfile>]
# Programs the Zynq PL over JTAG (board boot-mode jumpers set to JTAG).  Needs a connected, powered ZedBoard.
# Reports success only when the device's DONE property is 1 after programming.
source [file join [file dirname [file normalize [info script]]] common.tcl]
set bit [file join $proj_root build $top_module.bit]
if {[llength $argv] > 0} { set bit [file normalize [lindex $argv 0]] }
if {![file exists $bit]} { fail "bitstream $bit not found - run generate_bitstream.tcl first" }

open_hw_manager
if {[catch {connect_hw_server -allow_non_jtag} err]} { fail "cannot connect to hw_server: $err" }
if {[catch {open_hw_target} err]} { fail "no JTAG target found (is the ZedBoard powered and connected?): $err" }
set dev [lindex [get_hw_devices xc7z020*] 0]
if {$dev eq ""} { fail "no xc7z020 device on the JTAG chain: [get_hw_devices]" }
current_hw_device $dev
set_property PROGRAM.FILE $bit $dev
if {[catch {program_hw_devices $dev} err]} { fail "programming failed: $err" }
refresh_hw_device $dev
set done [get_property REGISTER.IR.BIT5_DONE $dev]
if {$done ne "1"} { fail "programming command returned but DONE=$done" }
puts "FPGA programmed from $bit (DONE=1)"
close_hw_target
disconnect_hw_server
close_hw_manager
