# Program the ZedBoard PL over JTAG and check that the FPGA reports DONE.
# Works in the Vivado GUI Tcl Console and in batch mode:
#     source F:/nanov_dot4_project_v4/nanov_dot4/fpga/tcl/program_board.tcl
#     vivado -mode batch -source fpga/tcl/program_board.tcl -tclargs <path/to/zedboard_nanov_dot4_top.bit>
# Bitstream: first argument, else the open project's impl_1 run, else <root>/build/zedboard_nanov_dot4_top.bit.
# Board: ZedBoard powered and connected by the USB-JTAG (PROG) port, boot-mode jumpers set to JTAG
# (see the ZedBoard Hardware User Guide).  Nothing needs to be attached to Pmod JA: the demo program is
# inside the bitstream (on-chip block RAM).
set _pb_dir  [file dirname [file normalize [info script]]]
set _pb_root [file normalize [file join $_pb_dir .. ..]]

proc pb_find_bit {root} {
    global argv
    if {[info exists argv] && [llength $argv] > 0 && [file exists [lindex $argv 0]]} { return [file normalize [lindex $argv 0]] }
    if {[llength [get_projects -quiet]] > 0} {
        set rd [get_property DIRECTORY [get_runs impl_1]]
        set b [glob -nocomplain -directory $rd *.bit]
        if {[llength $b] > 0} { return [lindex $b 0] }
    }
    set b [file join $root build zedboard_nanov_dot4_top.bit]
    if {[file exists $b]} { return $b }
    return ""
}

set _bit [pb_find_bit $_pb_root]
if {$_bit eq ""} { error "no bitstream found - run the implementation / write_bitstream step first (or pass the .bit path)" }
puts "Bitstream: $_bit"

open_hw_manager
if {[catch {connect_hw_server -allow_non_jtag} err]} { error "cannot start/connect hw_server: $err" }
if {[catch {open_hw_target} err]} {
    error "no JTAG target: $err\n  -> board powered? USB cable in the PROG/JTAG port? Digilent cable drivers installed?"
}
set _dev [lindex [get_hw_devices xc7z020*] 0]
if {$_dev eq ""} { error "no xc7z020 on the JTAG chain, found: [get_hw_devices]" }
current_hw_device $_dev
set_property PROGRAM.FILE $_bit $_dev
program_hw_devices $_dev
refresh_hw_device $_dev
set _done [get_property REGISTER.IR.BIT5_DONE $_dev]
if {$_done ne "1"} { error "programming finished but DONE=$_done" }
puts "================================================================"
puts " FPGA programmed (DONE=1).  The demo program starts by itself."
puts " Slide switches SW2..SW0 select a vector; LEDs LD7..LD0 show the"
puts " low byte of dot4(A,B) (BTNC = reset):"
puts "   SW=000 -> LD=00000100 (0x04)     SW=100 -> LD=11111100 (0xFC)"
puts "   SW=001 -> LD=01000110 (0x46)     SW=101 -> LD=10000000 (0x80)"
puts "   SW=010 -> LD=01100100 (0x64)     SW=110 -> LD=00010100 (0x14)"
puts "   SW=011 -> LD=11110110 (0xF6)     SW=111 -> LD=01111000 (0x78)"
puts " All LEDs on (0xFF) = the accelerator result differed from the table."
puts "================================================================"
