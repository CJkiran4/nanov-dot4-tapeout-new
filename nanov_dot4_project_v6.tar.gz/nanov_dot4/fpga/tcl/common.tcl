# Shared settings for the ZedBoard Vivado flow (Vivado 2024.1).  Sourced by every script.
# Run all scripts from anywhere; paths are resolved relative to this file.
set script_dir  [file dirname [file normalize [info script]]]
set proj_root   [file normalize [file join $script_dir .. ..]]
set proj_name   zedboard_nanov_dot4
set proj_dir    [file join $proj_root build vivado]
set rpt_dir     [file join $proj_root reports vivado]
set part        xc7z020clg484-1
set top_module  zedboard_nanov_dot4_top
set sim_top     tb_nanov_dot4_system

# Dot4 architecture: 1 = shared 8x8 multiplier (default), 0 = four parallel multipliers.
# Override with the environment variable DOT4_SHARED (create_project.tcl bakes it into the project).
set dot4_shared 1
if {[info exists ::env(DOT4_SHARED)]} { set dot4_shared $::env(DOT4_SHARED) }

proc fail {msg} {
    puts stderr "ERROR: $msg"
    exit 1
}

proc require_version {} {
    set v [version -short]
    if {![string match "2024.1*" $v]} {
        puts "WARNING: these scripts target Vivado 2024.1, running $v"
    }
}

# Fail unless a run finished successfully.  $run is a run object name such as synth_1.
proc check_run {run} {
    set status [get_property STATUS [get_runs $run]]
    puts "Run $run status: $status"
    if {[get_property PROGRESS [get_runs $run]] ne "100%" || [string match "*ERROR*" $status] || [string match "*Failed*" $status]} {
        fail "run $run did not complete successfully ($status)"
    }
}

proc open_existing_project {} {
    global proj_dir proj_name
    set xpr [file join $proj_dir $proj_name.xpr]
    if {![file exists $xpr]} { fail "project $xpr not found - run create_project.tcl first" }
    open_project $xpr
}
