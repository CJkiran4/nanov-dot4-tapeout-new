# vivado -mode batch -source fpga/tcl/create_project.tcl            (optionally: DOT4_SHARED=0)
source [file join [file dirname [file normalize [info script]]] common.tcl]
require_version

file mkdir $proj_dir
file mkdir $rpt_dir
create_project -force $proj_name $proj_dir -part $part

# ---- design sources (the six upstream NanoV files are byte-identical to MichaelBell/nanoV e1a405e) ----
set rtl_files [list \
    [file join $proj_root rtl upstream alu.v] \
    [file join $proj_root rtl upstream core.v] \
    [file join $proj_root rtl upstream cpu.v] \
    [file join $proj_root rtl upstream register.v] \
    [file join $proj_root rtl upstream shift.v] \
    [file join $proj_root rtl upstream multiply.v] \
    [file join $proj_root rtl dot4_accel.v] \
    [file join $proj_root rtl nanov_mmio_decoder.v] \
    [file join $proj_root rtl nanov_dot4_soc.v] \
    [file join $proj_root fpga spi_mem_bram.v] \
    [file join $proj_root fpga board_spi_mem.v] \
    [file join $proj_root fpga zedboard_nanov_dot4_top.v]]
foreach f $rtl_files { if {![file exists $f]} { fail "missing source $f" } }
add_files -norecurse -fileset sources_1 $rtl_files
set_property file_type Verilog [get_files $rtl_files]

# upstream multiply.v instantiates a sky130 scan flop unless SIMPLE_MULTIPLY is defined; the FPGA must use the
# behavioural branch.
set_property verilog_define {SIMPLE_MULTIPLY} [get_filesets sources_1]
set_property generic "DOT4_SHARED=$dot4_shared" [get_filesets sources_1]
set_property top $top_module [get_filesets sources_1]

# ---- constraints ----
set xdc [file join $proj_root fpga zedboard_nanov_dot4.xdc]
if {![file exists $xdc]} { fail "missing $xdc" }
add_files -norecurse -fileset constrs_1 $xdc

# ---- simulation sources (Vivado's own UNISIM models are used; fpga/sim/unisim_stubs.v is NOT added) ----
set sim_files [list \
    [file join $proj_root sim tb_nanov_dot4_system.v] \
    [file join $proj_root sim sim_spi_ram.v]]
add_files -norecurse -fileset sim_1 $sim_files
set_property verilog_define {SIMPLE_MULTIPLY} [get_filesets sim_1]
set_property top $sim_top [get_filesets sim_1]
set_property top_lib xil_defaultlib [get_filesets sim_1]

update_compile_order -fileset sources_1
puts "Created project $proj_dir/$proj_name.xpr  part=$part  top=$top_module  DOT4_SHARED=$dot4_shared"
close_project
