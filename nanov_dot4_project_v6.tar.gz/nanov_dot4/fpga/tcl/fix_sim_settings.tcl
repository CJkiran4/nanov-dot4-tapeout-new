# Fix the Vivado simulation setup for an already-created project (GUI project, not the scripted one).
#   1. defines SIMPLE_MULTIPLY (otherwise multiply.v needs the SKY130 cell sky130_fd_sc_hd__sdfxtp_1)
#   2. sets the simulation top, enables the DEBUG trace
#   3. deletes the stale compiled simulation files (xelab runs with --incr and would reuse them)
#   4. copies prog_dot4.mem into the xsim run folder
# Use: open the project in Vivado, edit $root below, then in the Tcl Console:
#        source F:/nanov_dot4_project_v4/nanov_dot4/fpga/tcl/fix_sim_settings.tcl
set root "F:/nanov_dot4_project_v4/nanov_dot4"      ;# <-- folder that contains rtl/ sim/ sw/ fpga/
set sim_top tb_nanov_dot4_system
set mem_src [file join $root sw prog_dot4.mem]

if {![file exists $mem_src]} { error "program image not found: $mem_src (edit \$root)" }

# 1. define for synthesis and simulation filesets
foreach fs {sources_1 sim_1} {
    set_property verilog_define {SIMPLE_MULTIPLY} [get_filesets $fs]
}
# also pass it straight to the compiler (harmless if it is applied twice)
set_property -name {xsim.compile.xvlog.more_options} -value {-d SIMPLE_MULTIPLY} -objects [get_filesets sim_1]

# 2. top and generics (DEBUG=1 prints the first instructions; remove it later with: set_property generic {} [get_filesets sim_1])
set_property top $sim_top [get_filesets sim_1]
set_property generic {DEBUG=1} [get_filesets sim_1]
update_compile_order -fileset sim_1

# 3. throw away stale compiled output
catch {close_sim -force}
set proj_dir [get_property DIRECTORY [current_project]]
set proj_nm  [get_property NAME [current_project]]
set simdir   [file join $proj_dir "$proj_nm.sim" sim_1 behav xsim]
# Windows refuses to delete files an open simulation still holds (e.g. xelab.pb) - never let that stop the script.
if {[catch {file delete -force [file join $simdir xsim.dir]} err]} {
    puts "WARNING: could not delete old compiled files ($err) - close the simulation window and rerun if the define seems ignored"
}
file mkdir $simdir

# 4. program image next to where xsim runs
file copy -force $mem_src [file join $simdir prog_dot4.mem]

puts "verilog_define (sim_1)     : [get_property verilog_define [get_filesets sim_1]]"
puts "verilog_define (sources_1) : [get_property verilog_define [get_filesets sources_1]]"
puts "generic (sim_1)            : [get_property generic [get_filesets sim_1]]"
puts "simulation top             : [get_property top [get_filesets sim_1]]"
puts "mem copied to              : [file join $simdir prog_dot4.mem]"
puts "Now run: launch_simulation   then:   run all"
