# vivado -mode batch -source fpga/tcl/generate_bitstream.tcl      (needs a routed impl_1)
# Succeeds only if the .bit file actually exists afterwards.
source [file join [file dirname [file normalize [info script]]] common.tcl]
require_version
open_existing_project
if {[get_property PROGRESS [get_runs impl_1]] ne "100%"} { fail "impl_1 is not complete - run run_implementation.tcl first" }
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1
check_run impl_1
set bit [file join $proj_dir $proj_name.runs impl_1 $top_module.bit]
if {![file exists $bit]} { fail "bitstream $bit was not produced" }
set out [file join $proj_root build $top_module.bit]
file copy -force $bit $out
puts "Bitstream written: $out ([file size $out] bytes)"
close_project
