# vivado -mode batch -source fpga/tcl/run_synthesis.tcl
source [file join [file dirname [file normalize [info script]]] common.tcl]
require_version
open_existing_project
file mkdir $rpt_dir
reset_run synth_1
launch_runs synth_1 -jobs 4
wait_on_run synth_1
check_run synth_1
open_run synth_1 -name synth_1
report_utilization    -file [file join $rpt_dir utilization_synth.rpt]
report_timing_summary -file [file join $rpt_dir timing_summary_synth.rpt] -delay_type min_max -max_paths 10
report_clocks         -file [file join $rpt_dir clocks_synth.rpt]
check_timing          -file [file join $rpt_dir check_timing_synth.rpt]
puts "Synthesis finished; reports in $rpt_dir"
close_project
