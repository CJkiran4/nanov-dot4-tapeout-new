# vivado -mode batch -source fpga/tcl/run_implementation.tcl      (needs a successful synth_1)
source [file join [file dirname [file normalize [info script]]] common.tcl]
require_version
open_existing_project
file mkdir $rpt_dir
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} { fail "synth_1 is not complete - run run_synthesis.tcl first" }
reset_run impl_1
launch_runs impl_1 -jobs 4
wait_on_run impl_1
check_run impl_1
open_run impl_1
report_utilization    -file [file join $rpt_dir utilization_impl.rpt]
report_timing_summary -file [file join $rpt_dir timing_summary_impl.rpt] -delay_type min_max -max_paths 10
report_route_status   -file [file join $rpt_dir route_status.rpt]
report_drc            -file [file join $rpt_dir drc_impl.rpt]
report_power          -file [file join $rpt_dir power_impl.rpt]
puts "Implementation finished; reports in $rpt_dir"
close_project
