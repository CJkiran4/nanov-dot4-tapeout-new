# vivado -mode batch -source fpga/tcl/run_simulation.tcl
# Behavioural simulation with xsim of the self-checking system testbench for both Dot4 variants.
# The testbench loads sw/prog_dot4.mem by relative path, so xsim is run with the project root as cwd.
# Fails (exit 1) unless the log contains exactly one "RESULT: PASS" and no "RESULT: FAIL"/"FAIL".
source [file join [file dirname [file normalize [info script]]] common.tcl]
require_version
file mkdir $rpt_dir
cd $proj_root

set rtl {rtl/upstream/alu.v rtl/upstream/core.v rtl/upstream/cpu.v rtl/upstream/register.v rtl/upstream/shift.v
         rtl/upstream/multiply.v rtl/dot4_accel.v rtl/nanov_mmio_decoder.v rtl/nanov_dot4_soc.v
         sim/sim_spi_ram.v sim/tb_nanov_dot4_system.v}

foreach shared {1 0} {
    set snap sim_shared$shared
    set log  [file join $rpt_dir "xsim_shared$shared.log"]
    # >& / >>& send stdout+stderr of the tool to the log file; a non-zero exit status raises a Tcl error.
    if {[catch {exec xvlog -sv -d SIMPLE_MULTIPLY {*}$rtl >& $log} err]} { fail "xvlog failed (variant $shared): see $log" }
    if {[catch {exec xelab -debug off -relax work.$sim_top -s $snap --generic_top "SHARED=$shared" >>& $log} err]} { fail "xelab failed (variant $shared): see $log" }
    if {[catch {exec xsim $snap -runall >>& $log} err]} { fail "xsim failed (variant $shared): see $log" }
    set fh [open $log r]; set txt [read $fh]; close $fh
    set npass [llength [regexp -all -inline {RESULT: PASS} $txt]]
    if {$npass != 1 || [regexp {RESULT: FAIL} $txt] || [regexp {(^|\n)FAIL} $txt]} {
        fail "simulation of Dot4 variant SHARED=$shared did not pass, see $log"
    }
    puts "xsim SHARED=$shared: PASS (log: $log)"
}
# remove xsim scratch files created in the project root
foreach f [glob -nocomplain xsim.dir xvlog.* xelab.* xsim.* webtalk* .Xil] { file delete -force $f }
puts "run_simulation.tcl: all xsim runs passed"
