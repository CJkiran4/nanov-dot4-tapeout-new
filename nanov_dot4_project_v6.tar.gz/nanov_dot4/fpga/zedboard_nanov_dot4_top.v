// ZedBoard (Zynq-7020, xc7z020clg484-1) wrapper for nanov_dot4_soc.
//
// Clocking : PL oscillator GCLK (100 MHz) -> MMCME2_BASE -> 12.5 MHz CPU clock.
//            12.5 MHz is close to the 12 MHz of the original iCEFUN design; NanoV's SPI
//            interface was never intended to run from a 100 MHz clock.
// Reset    : BTNC (active high) OR MMCM not locked holds NanoV in reset.
// GPIO     : gpio_out[7:0] -> LD7..LD0, gpio_in[2:0] <- SW2..SW0
// SPI mem  : INTERNAL_MEM=1 (default): the program lives in on-chip block RAM (board_spi_mem, demo program
//            sw/prog_board.S) - the board runs with nothing attached.  The SPI signals are still mirrored on
//            Pmod JA (JA1=CS JA2=MOSI JA4=SCK; JA3 input ignored) for a logic analyser.
//            INTERNAL_MEM=0: external SPI memory on Pmod JA, standard Digilent SPI-Pmod order
//            JA1=CS JA2=MOSI JA3=MISO JA4=SCK; the module choice is NOT specified by this project.
//
// The SPI clock is generated exactly as in upstream nanoV_top (inverted CPU clock gated by
// spi_clk_enable) and leaves the FPGA through ordinary fabric logic; Vivado will warn about
// a clock-derived data output.  Replacing that with an ODDR is a possible later improvement.
`default_nettype none

module zedboard_nanov_dot4_top #(
    parameter DOT4_SHARED  = 1,
    parameter INTERNAL_MEM = 1
) (
    input  wire       GCLK,
    input  wire       BTNC,
    input  wire [2:0] SW,
    output wire [7:0] LD,
    output wire       JA1,   // SPI CS
    output wire       JA2,   // SPI MOSI
    input  wire       JA3,   // SPI MISO
    output wire       JA4    // SPI SCK
);

    // ---- 100 MHz -> 12.5 MHz (VCO = 100 MHz * 10 = 1000 MHz, CLKOUT0 = VCO / 80) ----
    wire clkfb_out, clkfb_in, clk_mmcm, clk_cpu, locked;

    MMCME2_BASE #(
        .BANDWIDTH         ("OPTIMIZED"),
        .CLKIN1_PERIOD     (10.000),
        .DIVCLK_DIVIDE     (1),
        .CLKFBOUT_MULT_F   (10.000),
        .CLKOUT0_DIVIDE_F  (80.000),
        .STARTUP_WAIT      ("FALSE")
    ) u_mmcm (
        .CLKIN1   (GCLK),
        .CLKFBIN  (clkfb_in),
        .CLKFBOUT (clkfb_out),
        .CLKOUT0  (clk_mmcm),
        .LOCKED   (locked),
        .PWRDWN   (1'b0),
        .RST      (1'b0)
    );
    BUFG u_bufg_fb  (.I(clkfb_out), .O(clkfb_in));
    BUFG u_bufg_cpu (.I(clk_mmcm),  .O(clk_cpu));

    // ---- reset: asynchronous assert, synchronous release in the CPU clock domain ----
    wire rst_async = BTNC | ~locked;
    reg  [2:0] rst_sync = 3'b000;
    always @(posedge clk_cpu or posedge rst_async) begin
        if (rst_async) rst_sync <= 3'b000;
        else           rst_sync <= {rst_sync[1:0], 1'b1};
    end
    wire rst_n = rst_sync[2];

    // ---- two-flop synchroniser for the slide switches (read as GPIO_IN) ----
    reg [2:0] sw_m = 3'b000, sw_s = 3'b000;
    always @(posedge clk_cpu) begin
        sw_m <= SW;
        sw_s <= sw_m;
    end

    wire spi_sel, spi_mosi, spi_sck, spi_en, spi_miso_int, spi_miso_soc;

    nanov_dot4_soc #(
        .ENABLE_DOT4 (1),
        .DOT4_SHARED (DOT4_SHARED)
    ) u_soc (
        .clk         (clk_cpu),
        .rst_n       (rst_n),
        .spi_miso    (spi_miso_soc),
        .spi_select  (spi_sel),
        .spi_clk_out (spi_sck),
        .spi_clk_en  (spi_en),
        .spi_mosi    (spi_mosi),
        .gpio_in     (sw_s),
        .gpio_out    (LD)
    );

    assign JA1 = spi_sel;
    assign JA2 = spi_mosi;
    assign JA4 = spi_sck;

    generate
        if (INTERNAL_MEM != 0) begin : g_int_mem
            board_spi_mem u_mem (
                .clk(clk_cpu), .spi_select(spi_sel), .spi_mosi(spi_mosi),
                .spi_clk_en(spi_en), .spi_miso(spi_miso_int)
            );
            assign spi_miso_soc = spi_miso_int;
            wire _unused_ja3 = &{1'b0, JA3};
        end else begin : g_ext_mem
            assign spi_miso_int = 1'b0;
            assign spi_miso_soc = JA3;
            wire _unused_en = &{1'b0, spi_en, spi_miso_int};
        end
    endgenerate

endmodule

`default_nettype wire
