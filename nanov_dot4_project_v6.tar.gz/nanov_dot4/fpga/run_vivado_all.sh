#!/usr/bin/env bash
# Batch driver. Stops at the first failing stage (each Tcl script exits non-zero on failure).
# usage: fpga/run_vivado_all.sh [project|sim|synth|impl|timing|bit|program|all]
set -euo pipefail
cd "$(dirname "$0")/tcl"
V="vivado -mode batch -nojournal -notrace"
stage() { echo "=== $1 ==="; $V -log "../../build/vivado_$1.log" -source "$2.tcl"; }
mkdir -p ../../build
case "${1:-all}" in
  project) stage create_project create_project ;;
  sim)     stage run_simulation run_simulation ;;
  synth)   stage run_synthesis run_synthesis ;;
  impl)    stage run_implementation run_implementation ;;
  timing)  stage report_timing report_timing ;;
  bit)     stage generate_bitstream generate_bitstream ;;
  program) stage program_fpga program_fpga ;;
  all) for s in create_project run_simulation run_synthesis run_implementation report_timing generate_bitstream; do stage $s $s; done
       echo "Bitstream built. Run '$0 program' with the board attached to program it." ;;
  *) echo "unknown stage"; exit 2 ;;
esac
