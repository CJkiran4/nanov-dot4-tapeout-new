// Pin-level smoke test of zedboard_nanov_dot4_top (uses the behavioural MMCM stub).
// Runs sw/prog_baseline.mem from an SPI RAM model attached to Pmod JA and checks, via the board
// pins only: reset release, SW[2:0] -> GPIO_IN readback, LD <- GPIO_OUT, and the end marker.
// Run from the project root.  Expected values are literals derived from the program source.
`timescale 1ns/1ps
`default_nettype none
module tb_zedboard_top;
    reg GCLK = 0;  always #5 GCLK = ~GCLK;           // 100 MHz
    reg BTNC = 1;
    reg [2:0] SW = 3'b101;
    wire [7:0] LD;
    wire JA1, JA2, JA3, JA4;

    zedboard_nanov_dot4_top #(.INTERNAL_MEM(0)) dut (.GCLK(GCLK), .BTNC(BTNC), .SW(SW), .LD(LD),
                                 .JA1(JA1), .JA2(JA2), .JA3(JA3), .JA4(JA4));
    sim_spi_ram #(.INIT_FILE("sw/prog_baseline.mem")) ram (
        .spi_clk(JA4), .spi_mosi(JA2), .spi_select(JA1), .spi_miso(JA3),
        .debug_clk(1'b0), .debug_addr(24'd0), .debug_data());

    function [31:0] brev8(input [31:0] w);
        integer bi;
        begin for (bi = 0; bi < 32; bi = bi + 1) brev8[(bi/8)*8 + 7 - (bi%8)] = w[bi]; end
    endfunction
    function [31:0] rd(input [31:0] a); rd = brev8(ram.data[a >> 2]); endfunction

    integer errors = 0, n = 0;
    task check(input c, input [8*56-1:0] m);
        begin if (!c) begin errors = errors + 1; $display("FAIL: %0s", m); end end
    endtask

    initial begin : watchdog #20_000_000; $display("FAIL: TIMEOUT"); $display("RESULT: FAIL"); $finish; end

    initial begin
        #200 BTNC = 0;
        while (rd(32'h13fc) !== 32'hC0DE600D && n < 2_000_000) begin @(posedge GCLK); n = n + 1; end
        check(n < 2_000_000, "end marker not written (timeout)");
        repeat (4000) @(posedge GCLK);
        check(rd(32'h1344) === 32'd5,        "SW[2:0]=101 not visible through GPIO_IN");
        check(rd(32'h1340) === 32'hA5,       "GPIO_OUT readback");
        check(LD === 8'h3C,                  "LD pins != final GPIO_OUT (0x3C)");
        check(rd(32'h1240) === 32'd42,       "jal/jalr result");
        check(rd(32'h1234) === 32'h12345678 * 32'hBEEF, "mul result");
        // reset via BTNC returns LEDs to 0
        BTNC = 1; repeat (40) @(posedge GCLK); 
        check(LD === 8'h00, "BTNC reset did not clear LD");
        BTNC = 0;
        $display("pins ok after %0d GCLK cycles, LD final checked, errors=%0d", n, errors);
        if (errors == 0) $display("RESULT: PASS"); else $display("RESULT: FAIL");
        $finish;
    end
endmodule
`default_nettype wire
