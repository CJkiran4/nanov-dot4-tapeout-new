// SIMULATION / LINT STUBS ONLY - never added to the Vivado project (Vivado supplies the real
// UNISIM models).  Behavioural stand-ins so the ZedBoard wrapper can be elaborated with
// Icarus / Verilator / Yosys.  The MMCM stub divides CLKIN1 by 8 (100 MHz -> 12.5 MHz) and
// asserts LOCKED after 16 input cycles; it does not model jitter, phase or VCO limits.
module BUFG (input wire I, output wire O);
    assign O = I;
endmodule

module MMCME2_BASE #(
    parameter BANDWIDTH = "OPTIMIZED",
    parameter real CLKIN1_PERIOD = 10.0,
    parameter integer DIVCLK_DIVIDE = 1,
    parameter real CLKFBOUT_MULT_F = 10.0,
    parameter real CLKOUT0_DIVIDE_F = 80.0,
    parameter STARTUP_WAIT = "FALSE"
) (
    input  wire CLKIN1, input wire CLKFBIN, input wire PWRDWN, input wire RST,
    output wire CLKFBOUT, output wire CLKOUT0, output reg LOCKED
);
    reg [2:0] div = 3'd0;
    reg [4:0] lockcnt = 5'd0;
    initial LOCKED = 1'b0;
    always @(posedge CLKIN1) begin
        div <= div + 3'd1;
        if (lockcnt != 5'd16) lockcnt <= lockcnt + 5'd1; else LOCKED <= 1'b1;
    end
    assign CLKOUT0  = div[2];
    assign CLKFBOUT = CLKIN1;
endmodule
