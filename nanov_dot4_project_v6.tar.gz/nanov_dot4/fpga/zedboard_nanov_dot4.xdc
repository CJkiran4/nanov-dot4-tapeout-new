# ZedBoard (Zynq-7020, xc7z020clg484-1) constraints for zedboard_nanov_dot4_top.
#
# SOURCE OF TRUTH: Digilent/Avnet "Zedboard-Master.xdc" (Avnet UCF Generator V0.4.0), fetched from
#   https://github.com/Digilent/digilent-xdc/blob/master/Zedboard-Master.xdc
# Every PACKAGE_PIN below was checked against that file (pin location and net name).  The master
# file's banks are: 13 = fixed 3.3 V; 33 = fixed 3.3 V; 34 and 35 = Vadj (jumper J18), default 1.8 V.
# Nothing here is copied from a ZC702 file and no Tiny Tapeout pin numbers are used.
#
# Deliberately NOT included: set_input_delay / set_output_delay / false-path / generated clock
# constraints.  The MMCM output clock is derived automatically by Vivado from create_clock below.
# The SPI pins (JA1..JA4) are therefore unconstrained for I/O timing - see README.

# ---------------------------------------------------------------------------
# Clock: GCLK, Bank 13 (master XDC: "#set_property PACKAGE_PIN Y9 [get_ports {GCLK}]")
# 100 MHz period is the ZedBoard PL oscillator frequency (the master XDC does not state it;
# confirm against the ZedBoard Hardware User Guide before relying on timing results).
# ---------------------------------------------------------------------------
set_property PACKAGE_PIN Y9 [get_ports GCLK]
set_property IOSTANDARD LVCMOS33 [get_ports GCLK]
create_clock -name sys_clk -period 10.000 [get_ports GCLK]

# ---------------------------------------------------------------------------
# User push button BTNC (reset), Bank 34 -> LVCMOS18 with Vadj = 1.8 V (J18 default)
# ---------------------------------------------------------------------------
set_property PACKAGE_PIN P16 [get_ports BTNC]
set_property IOSTANDARD LVCMOS18 [get_ports BTNC]

# ---------------------------------------------------------------------------
# User DIP switches SW0..SW2 (GPIO_IN[2:0]), Bank 35 -> LVCMOS18 with Vadj = 1.8 V
# ---------------------------------------------------------------------------
set_property PACKAGE_PIN F22 [get_ports {SW[0]}]
set_property PACKAGE_PIN G22 [get_ports {SW[1]}]
set_property PACKAGE_PIN H22 [get_ports {SW[2]}]
set_property IOSTANDARD LVCMOS18 [get_ports {SW[*]}]

# ---------------------------------------------------------------------------
# User LEDs LD0..LD7 (GPIO_OUT[7:0]), Bank 33, fixed 3.3 V
# ---------------------------------------------------------------------------
set_property PACKAGE_PIN T22 [get_ports {LD[0]}]
set_property PACKAGE_PIN T21 [get_ports {LD[1]}]
set_property PACKAGE_PIN U22 [get_ports {LD[2]}]
set_property PACKAGE_PIN U21 [get_ports {LD[3]}]
set_property PACKAGE_PIN V22 [get_ports {LD[4]}]
set_property PACKAGE_PIN W22 [get_ports {LD[5]}]
set_property PACKAGE_PIN U19 [get_ports {LD[6]}]
set_property PACKAGE_PIN U14 [get_ports {LD[7]}]
set_property IOSTANDARD LVCMOS33 [get_ports {LD[*]}]

# ---------------------------------------------------------------------------
# Pmod JA (top row, pins 1-4), Bank 13, fixed 3.3 V
#   JA1 = SPI CS, JA2 = MOSI, JA3 = MISO, JA4 = SCK  (Digilent SPI Pmod pin order)
# ---------------------------------------------------------------------------
set_property PACKAGE_PIN Y11  [get_ports JA1]
set_property PACKAGE_PIN AA11 [get_ports JA2]
set_property PACKAGE_PIN Y10  [get_ports JA3]
set_property PACKAGE_PIN AA9  [get_ports JA4]
set_property IOSTANDARD LVCMOS33 [get_ports {JA1 JA2 JA3 JA4}]
