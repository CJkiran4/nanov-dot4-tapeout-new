# NanoV RV32E + INT8 Dot4 accelerator (Tiny Tapeout SKY130 submission files)

![gds](../../workflows/gds/badge.svg) ![test](../../workflows/test/badge.svg)

This directory is laid out as the root of a Tiny Tapeout repository created from
`TinyTapeout/ttsky-verilog-template` (workflows copied from that template; they reference
`tt-gds-action@ttsky26d`). See `docs/info.md` for the datasheet text and `info.yaml` for the manifest.

Status (see top-level `README.md` for evidence): RTL cocotb test PASS; gate-level test, GDS build and
precheck NOT RUN (they need the Tiny Tapeout GitHub Actions flow / OpenLane, not available in the authoring
environment). The tile count in `info.yaml` is provisional.

To submit: rename `tt_um_nanov_dot4_accel` to include your GitHub user name (module, `info.yaml`, `test/tb.v`),
set `author`, push to a GitHub repository and let the `gds` workflow run.
