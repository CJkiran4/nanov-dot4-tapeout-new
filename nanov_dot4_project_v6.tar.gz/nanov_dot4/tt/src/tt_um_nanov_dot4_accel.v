/*
 * Copyright (c) 2024 Michael Bell (NanoV CPU, Apache-2.0); Dot4 integration - this project
 * SPDX-License-Identifier: Apache-2.0
 */
`default_nettype none

// Tiny Tapeout top level for NanoV (RV32E, bit-serial) + MMIO INT8 Dot4 accelerator.
//
// NOTE: the module name must be unique across the shuttle; Tiny Tapeout asks for a name that
// includes your GitHub user name (tt_um_<user>_<project>).  Rename here, in info.yaml and in
// test/tb.v together before submitting.
//
// Pin plan (SPI pins follow the official "SPI RAM" pinout of the Tiny Tapeout pinout page):
//   ui_in[2:0]   GPIO_IN  (0x10000004 bits 2:0)        ui_in[7:3]  unused
//   uo_out[7:0]  GPIO_OUT (0x10000000 bits 7:0)
//   uio[0]  SPI CS   (output)     uio[1]  SPI MOSI (output)
//   uio[2]  SPI MISO (input)      uio[3]  SPI SCK  (output)     uio[7:4] unused inputs
module tt_um_nanov_dot4_accel (
    input  wire [7:0] ui_in,    // Dedicated inputs
    output wire [7:0] uo_out,   // Dedicated outputs
    input  wire [7:0] uio_in,   // IOs: Input path
    output wire [7:0] uio_out,  // IOs: Output path
    output wire [7:0] uio_oe,   // IOs: Enable path (active high: 0=input, 1=output)
    input  wire       ena,      // always 1 when the design is powered, so you can ignore it
    input  wire       clk,      // clock
    input  wire       rst_n     // reset_n - low to reset
);

    wire spi_cs, spi_mosi, spi_sck, spi_en;

    nanov_dot4_soc #(
        .ENABLE_DOT4 (1),
        .DOT4_SHARED (1)           // area-optimised shared 8x8 multiplier
    ) soc (
        .clk         (clk),
        .rst_n       (rst_n),
        .spi_miso    (uio_in[2]),
        .spi_select  (spi_cs),
        .spi_clk_out (spi_sck),
        .spi_clk_en  (spi_en),
        .spi_mosi    (spi_mosi),
        .gpio_in     (ui_in[2:0]),
        .gpio_out    (uo_out)
    );

    assign uio_out = {4'b0000, spi_sck, 1'b0, spi_mosi, spi_cs};
    assign uio_oe  = 8'b0000_1011;   // bits 0,1,3 driven; bit 2 (MISO) and 7:4 are inputs

    // List all unused inputs to prevent warnings
    wire _unused = &{ena, spi_en, ui_in[7:3], uio_in[7:3], uio_in[1:0], 1'b0};

endmodule
