#!/usr/bin/env python3
"""Build test/prog_tt.mem: the physical SPI-RAM image (bytes bit-reversed, see sw/build.sh) containing
sw/prog_dot4 at address 0 plus N=3 test vectors, as read by the cocotb test."""
import os, sys
here = os.path.dirname(os.path.abspath(__file__))
prog = [int(l, 16) for l in open(os.path.join(here, '..', '..', 'sw', 'prog_dot4.mem')) if l.strip()]

def brev8w(w):
    return sum(int('{:08b}'.format((w >> (8 * i)) & 0xFF)[::-1], 2) << (8 * i) for i in range(4))

VECTORS = [  # (A, B, CTRL)   CTRL: bit0 START, bit1 ACC, bit2 CLR
    (0x01020304, 0x05060708, 1),
    (0xFFFFFFFF, 0x01010101, 3),
    (0x80808080, 0x7F7F7F7F, 1),
]
mem = {}
for i, w in enumerate(prog):          # program image is already physical (bit-reversed) from build.sh
    mem[i] = w
mem[0x0FF0 >> 2] = brev8w(len(VECTORS))
for i, (a, b, c) in enumerate(VECTORS):
    base = (0x1000 >> 2) + 3 * i
    mem[base], mem[base + 1], mem[base + 2] = brev8w(a), brev8w(b), brev8w(c)
with open(os.path.join(here, 'prog_tt.mem'), 'w') as f:
    for addr in sorted(mem):
        f.write('@%x\n%08x\n' % (addr, mem[addr]))
print('wrote prog_tt.mem with', len(VECTORS), 'vectors')
