`default_nettype none
`timescale 1ns / 1ps

/* Testbench for tt_um_nanov_dot4_accel: instantiates the project and a SPI RAM model on uio[3:0]
   (CS=uio[0], MOSI=uio[1], MISO=uio[2], SCK=uio[3]), pre-loaded with test/prog_tt.mem. */
module tb ();

  initial begin
    $dumpfile("tb.fst");
    $dumpvars(0, tb);
    #1;
  end

  reg clk;
  reg rst_n;
  reg ena;
  reg [7:0] ui_in;
  reg [7:0] uio_in_ext;          // driven by cocotb; bit 2 is replaced by the RAM's MISO
  wire [7:0] uo_out;
  wire [7:0] uio_out;
  wire [7:0] uio_oe;
  wire miso;
  wire [7:0] uio_in = {uio_in_ext[7:3], miso, uio_in_ext[1:0]};
`ifdef GL_TEST
  wire VPWR = 1'b1;
  wire VGND = 1'b0;
`endif

  tt_um_nanov_dot4_accel user_project (
`ifdef GL_TEST
      .VPWR(VPWR),
      .VGND(VGND),
`endif
      .ui_in  (ui_in),
      .uo_out (uo_out),
      .uio_in (uio_in),
      .uio_out(uio_out),
      .uio_oe (uio_oe),
      .ena    (ena),
      .clk    (clk),
      .rst_n  (rst_n)
  );

  sim_spi_ram #(.INIT_FILE("prog_tt.mem")) ram (
      .spi_clk   (uio_out[3]),
      .spi_mosi  (uio_out[1]),
      .spi_select(uio_out[0]),
      .spi_miso  (miso),
      .debug_clk (1'b0),
      .debug_addr(24'd0),
      .debug_data()
  );

endmodule
