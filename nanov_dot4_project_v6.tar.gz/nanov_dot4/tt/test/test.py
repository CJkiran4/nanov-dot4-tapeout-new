# SPDX-License-Identifier: Apache-2.0
# End-to-end cocotb test of tt_um_nanov_dot4_accel: NanoV executes sw/prog_dot4 from the SPI RAM model,
# drives the Dot4 accelerator over MMIO, and the test recomputes every expected value independently.
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles

VECTORS = [(0x01020304, 0x05060708, 1), (0xFFFFFFFF, 0x01010101, 3), (0x80808080, 0x7F7F7F7F, 1)]


def brev8w(w):
    return sum(int('{:08b}'.format((w >> (8 * i)) & 0xFF)[::-1], 2) << (8 * i) for i in range(4))


def to_s8(x):
    return x - 256 if x > 127 else x


def dot4(a, b):
    return sum(to_s8((a >> (8 * i)) & 0xFF) * to_s8((b >> (8 * i)) & 0xFF) for i in range(4))


def ram_word(dut, byte_addr):
    return brev8w(int(dut.ram.data[byte_addr >> 2].value))


@cocotb.test()
async def test_dot4_program(dut):
    cocotb.start_soon(Clock(dut.clk, 83, unit="ns").start())   # ~12 MHz
    dut.ena.value = 1
    dut.ui_in.value = 0
    dut.uio_in_ext.value = 0
    dut.rst_n.value = 0
    await ClockCycles(dut.clk, 10)
    # in reset: pins must be in a defined state, SPI CS deasserted
    assert int(dut.uio_oe.value) == 0x0B, "uio_oe must drive CS/MOSI/SCK only"
    assert int(dut.uo_out.value) == 0
    dut.rst_n.value = 1

    acc, expected = 0, []
    for a, b, c in VECTORS:
        acc = (acc if c & 2 else 0) + dot4(a, b)
        expected.append(acc & 0xFFFFFFFF)

    done = False
    for _ in range(400):                       # explicit timeout: 400 * 1000 = 400k clocks
        await ClockCycles(dut.clk, 1000)
        if ram_word(dut, 0x17FC) == 0xC0DE600D:
            done = True
            break
    assert done, "program did not reach its end marker (timeout)"
    await ClockCycles(dut.clk, 2000)

    for i, e in enumerate(expected):
        got = ram_word(dut, 0x2000 + 4 * i)
        assert got == e, f"vector {i}: got {got:#010x}, expected {e:#010x}"
    assert ram_word(dut, 0x1408) == 70, "register-base MMIO path dot product"
    assert ram_word(dut, 0x140C) == 0, "CLR"
    assert ram_word(dut, 0x1410) == 0, "DONE cleared by CLR"
    assert ram_word(dut, 0x1414) == 0x6B
    assert int(dut.uo_out.value) == 0x6B, "GPIO_OUT pins"
    dut._log.info("all Dot4 results match the independent model: %s", [hex(e) for e in expected])
