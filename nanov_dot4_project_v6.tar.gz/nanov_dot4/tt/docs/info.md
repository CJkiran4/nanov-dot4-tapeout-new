<!---
Datasheet source for the Tiny Tapeout project page.
-->

## How it works

NanoV is a bit-serial RV32E RISC-V core by Michael Bell (Apache-2.0,
[MichaelBell/nanoV](https://github.com/MichaelBell/nanoV), revision `e1a405e`, included unmodified). It
fetches instructions and data from an external SPI RAM / FRAM (command `03h` read, `02h` write); one
"instruction cycle" is 32 clocks. The memory image uses the NanoV convention: the CPU consumes the SPI
stream LSB-first, so each byte stored in a standard SPI memory is bit-reversed relative to the RISC-V
binary (`sw/build.sh` does this).

Peripherals sit at `0x10000000` (register `tp` is hard-wired to that value, so `lw/sw imm(tp)` are single
instruction-cycle accesses):

| Address      | Access | Function |
|--------------|--------|----------|
| `0x10000000` | R/W    | GPIO_OUT, bits 7:0 -> `uo[7:0]`; read returns the register |
| `0x10000004` | R      | GPIO_IN, bits 2:0 <- `ui[2:0]` |
| `0x10000100` | R/W    | DOT_A: four packed signed int8 values (byte 0 = element 0) |
| `0x10000104` | R/W    | DOT_B: four packed signed int8 values |
| `0x10000108` | W      | DOT_CTRL: bit0 START, bit1 ACC (add to previous result), bit2 CLR |
| `0x10000108` | R      | DOT_STATUS: bit0 BUSY, bit1 DONE |
| `0x1000010C` | R      | DOT_RESULT: 32-bit signed accumulator (wraps on overflow) |

`result = (ACC ? result : 0) + sum(a[i] * b[i])`, i = 0..3, signed 8x8 products. Writes to A/B/CTRL while
BUSY are ignored. This build uses the area-optimised shared 8x8 multiplier (4 compute clocks); the parallel
four-multiplier variant is available as `DOT4_SHARED=0` in `nanov_dot4_soc` (about 1.3x the area).
Because NanoV reads a status word bit-serially (BUSY at counter 0, DONE at counter 1), the first poll after
START always reports "not done" for the shared variant; software must poll until DONE.

## How to test

Attach an SPI RAM/FRAM (e.g. Adafruit 4719 MB85RS4MT, as used by upstream NanoV) to `uio[0..3]` (CS, MOSI,
MISO, SCK), load a bit-reversed program image (see `test/make_image.py`), apply the clock and release
`rst_n`. Simulation: `cd test && make` (cocotb + Icarus).

## External hardware

SPI RAM or FRAM on `uio[3:0]`; optional LEDs on `uo[7:0]`, switches on `ui[2:0]`.
