// End-to-end test: NanoV CPU executes sw/prog_dot4.mem, driving the Dot4
// accelerator purely through MMIO (fast tp-relative path and the normal
// register-base path), with the program image and every test vector held in the
// external SPI RAM model.
//
// The testbench writes N vectors {A, B, CTRL} into RAM, lets the CPU run, then
// recomputes every expected result itself (integer arithmetic) and compares.
// Run twice via -Ptb_nanov_dot4_system.SHARED=0/1 to cover both architectures.
`timescale 1ns/1ps
`default_nettype none

module tb_nanov_dot4_system;
    parameter SHARED = 1;
    parameter NUM_RANDOM = 64;
    // Path of the program image.  Relative paths resolve against the simulator's working directory
    // (Vivado xsim: <proj>.sim/sim_1/behav/xsim); pass an absolute path if the file is not found.
    parameter PROG_FILE = "sw/prog_dot4.mem";
    // DEBUG=1 prints the memory words and the first instructions the CPU executes (for comparing simulators).
    parameter DEBUG = 0;

    reg clk = 0;
    reg rst_n = 0;
    always #40 clk = ~clk;

    wire miso, sel, sclk, mosi, sclk_en;
    wire [7:0] gpio_out;
    nanov_dot4_soc #(.ENABLE_DOT4(1), .DOT4_SHARED(SHARED)) dut (
        .clk(clk), .rst_n(rst_n),
        .spi_miso(miso), .spi_select(sel), .spi_clk_out(sclk), .spi_clk_en(sclk_en), .spi_mosi(mosi),
        .gpio_in(3'b000), .gpio_out(gpio_out));

`ifdef USE_BRAM_MEM
    // same test, but with the synthesizable on-chip SPI RAM (fpga/spi_mem_bram.v) instead of the behavioural model
    spi_mem_bram #(.ADDR_WORD_BITS(14)) ram (
        .clk(clk), .spi_select(sel), .spi_mosi(mosi), .spi_clk_en(sclk_en), .spi_miso(miso));
`else
    sim_spi_ram #(.INIT_FILE("")) ram (
        .spi_clk(sclk), .spi_mosi(mosi), .spi_select(sel), .spi_miso(miso),
        .debug_clk(1'b0), .debug_addr(24'd0), .debug_data());
`endif

    integer errors = 0, checks = 0;
    task check(input cond, input [8*60-1:0] msg);
        begin
            checks = checks + 1;
            if (!cond) begin
                errors = errors + 1;
                if (errors <= 40) $display("FAIL @%0t: %0s", $time, msg);
            end
        end
    endtask

    // Physical memory image holds bit-reversed bytes (see sw/build.sh).
    function [31:0] brev8(input [31:0] w);
        integer bi;
        begin
            for (bi = 0; bi < 32; bi = bi + 1)
                brev8[(bi / 8) * 8 + (7 - (bi % 8))] = w[bi];
        end
    endfunction
    function [31:0] rd_logical(input [31:0] byte_addr);
        rd_logical = brev8(ram.data[byte_addr >> 2]);
    endfunction
    task wr_logical(input [31:0] byte_addr, input [31:0] v);
        begin ram.data[byte_addr >> 2] = brev8(v); end
    endtask

    // ---- independent model ----
    function [31:0] model_dot(input [31:0] a, input [31:0] b);
        integer i, x, y, s;
        begin
            s = 0;
            for (i = 0; i < 4; i = i + 1) begin
                x = a[8*i +: 8]; if (x > 127) x = x - 256;
                y = b[8*i +: 8]; if (y > 127) y = y - 256;
                s = s + x * y;
            end
            model_dot = s;
        end
    endfunction

    localparam integer N_DIRECTED = 16;
    localparam integer N = N_DIRECTED + NUM_RANDOM;
    reg [31:0] vA [0:N-1], vB [0:N-1], vC [0:N-1], vE [0:N-1];

    integer i, li;
    reg [31:0] model_acc, r;

    task set_vec(input integer idx, input [31:0] a, input [31:0] b, input [31:0] c);
        begin vA[idx] = a; vB[idx] = b; vC[idx] = c; end
    endtask

    reg [7:0] hist [0:7];
    integer nh = 0;
    always @(gpio_out) if (rst_n && nh < 8) begin hist[nh] = gpio_out; nh = nh + 1; end

    initial begin : watchdog
        #60_000_000;
        $display("FAIL: TIMEOUT (watchdog)");
        $display("RESULT: FAIL");
        $finish;
    end

    // ---- status-poll instrumentation (observes the real CPU/MMIO traffic) ----
    // DOT_CTRL reads happen once per load instruction (data_in_read pulse).
    integer ctrl_reads = 0, starts = 0, clk_count = 0, last_start = -1000000, min_gap = 1000000;
    integer max_busy_run = 0, busy_run = 0;
    always @(posedge clk) if (rst_n) begin
        clk_count = clk_count + 1;
        if (dut.is_data_in && dut.mmio.sel == 4'd10) begin
            ctrl_reads = ctrl_reads + 1;
            if (clk_count - last_start < min_gap) min_gap = clk_count - last_start;
        end
        if (dut.dot_start) begin starts = starts + 1; last_start = clk_count; end
        if (dut.dot_busy) begin busy_run = busy_run + 1; if (busy_run > max_busy_run) max_busy_run = busy_run; end
        else busy_run = 0;
    end

    integer dbg_n = 0;
    always @(posedge clk) if (DEBUG != 0 && rst_n && dut.nano.counter == 5'd31 && dbg_n < 14) begin
        dbg_n = dbg_n + 1;
        $display("DBG #%0d t=%0t cyc=%0d instr=%h pc=%h sel=%b", dbg_n, $time, dut.nano.cycle,
                 {dut.nano.instr, 2'b11}, dut.nano.pc, sel);
    end

    // RAM-side view of the first SPI read (DEBUG=1): shows whether the memory model decoded the 0x03 command
    reg dbg_ram_once = 0;
    integer dbg_bits = 0;
    always @(negedge sclk) if (DEBUG != 0 && !dbg_ram_once && ram.start_count == 6'd32) begin
        dbg_ram_once = 1;
        $display("DBGRAM t=%0t at 32 command clocks: cmd=%h reading=%b writing=%b error=%b data[0]=%h",
                 $time, ram.cmd, ram.reading, ram.writing, ram.error, ram.data[0]);
    end
    always @(posedge clk) if (DEBUG != 0 && rst_n && ram.reading && dbg_bits < 40) begin
        dbg_bits = dbg_bits + 1;
        $display("DBGRAM read bit %0d: addr=%h miso=%b sel=%b", dbg_bits, ram.addr, miso, sel);
    end

    reg [8*128-1:0] prog_path;
    integer fd;
    integer wait_cycles;
    initial begin
        // ---------------- build vectors ----------------
        set_vec(0,  32'h80808080, 32'h80808080, 32'd1);   // 65536
        set_vec(1,  32'h7F7F7F7F, 32'h7F7F7F7F, 32'd1);   // 64516
        set_vec(2,  32'h80808080, 32'h7F7F7F7F, 32'd3);   // accumulate -65024
        set_vec(3,  32'h01020304, 32'h05060708, 32'd1);   // 70
        set_vec(4,  32'hFFFFFFFF, 32'h01010101, 32'd3);   // accumulate -4
        set_vec(5,  32'h00000007, 32'hFFFFFFFF, 32'd1);   // lane 0 only
        set_vec(6,  32'h00000700, 32'hFFFFFFFF, 32'd1);   // lane 1 only
        set_vec(7,  32'h00070000, 32'hFFFFFFFF, 32'd1);   // lane 2 only
        set_vec(8,  32'h07000000, 32'hFFFFFFFF, 32'd1);   // lane 3 only
        set_vec(9,  32'hFFFFFFFF, 32'h80000080, 32'd1);   // lanes 0 and 3
        set_vec(10, 32'h12345678, 32'h9ABCDEF0, 32'd5);   // CLR|START (no acc)
        set_vec(11, 32'h0FF00FF0, 32'hF00FF00F, 32'd3);   // accumulate
        set_vec(12, 32'h81818181, 32'h81818181, 32'd7);   // CLR|ACC|START -> equals plain dot
        set_vec(13, 32'h00000000, 32'h00000000, 32'd3);   // zero operands, accumulate (result unchanged)
        set_vec(14, 32'h80000001, 32'h7F00FF80, 32'd1);
        set_vec(15, 32'h7F7F7F7F, 32'h80808080, 32'd3);
        for (i = N_DIRECTED; i < N; i = i + 1) begin
            r = $urandom % 8;
            set_vec(i, $urandom, $urandom, (r < 4) ? 32'd1 : (r < 6) ? 32'd3 : (r == 6) ? 32'd5 : 32'd7);
        end

        // expected results
        model_acc = 0;
        for (i = 0; i < N; i = i + 1) begin
            if (vC[i][2]) model_acc = 0;
            model_acc = (vC[i][1] ? model_acc : 32'd0) + model_dot(vA[i], vB[i]);
            vE[i] = model_acc;
        end

        // load vectors into the SPI RAM image (after the model's own $readmemh)
        #1;
        // ---- load the program image explicitly (do not depend on the RAM model's own initial block) ----
        // Try PROG_FILE first, then the bare file name (the Vivado xsim run folder), then ../sw/.
        prog_path = PROG_FILE;
        fd = $fopen(prog_path, "r");
        if (fd == 0) begin prog_path = "prog_dot4.mem";        fd = $fopen(prog_path, "r"); end
        if (fd == 0) begin prog_path = "../sw/prog_dot4.mem";  fd = $fopen(prog_path, "r"); end
        if (fd == 0) begin
            $display("FAIL: cannot open the program image. Tried \"%0s\", \"prog_dot4.mem\", \"../sw/prog_dot4.mem\".", PROG_FILE);
            $display("      Copy prog_dot4.mem into the simulator run folder or pass an absolute PROG_FILE.");
            $display("RESULT: FAIL");
            $finish;
        end
        $fclose(fd);
        for (li = 0; li < 16384; li = li + 1) ram.data[li] = 32'd0;
        $readmemh(prog_path, ram.data);
        $display("program image loaded from \"%0s\": words 0..3 = %h %h %h %h", prog_path,
                 ram.data[0], ram.data[1], ram.data[2], ram.data[3]);
        if (ram.data[0] === 32'd0) begin
            $display("FAIL: program image is empty after loading - word 0 is zero.");
            $display("RESULT: FAIL");
            $finish;
        end
        wr_logical(32'h0FF0, N);
        for (i = 0; i < N; i = i + 1) begin
            wr_logical(32'h1000 + 12*i + 0, vA[i]);
            wr_logical(32'h1000 + 12*i + 4, vB[i]);
            wr_logical(32'h1000 + 12*i + 8, vC[i]);
        end

        // ---------------- run ----------------
        rst_n = 0;
        repeat (4) @(posedge clk);
        @(negedge clk); rst_n = 1;

        wait_cycles = 0;
        while (rd_logical(32'h17FC) !== 32'hC0DE600D && wait_cycles < 400_000) begin
            @(posedge clk);
            wait_cycles = wait_cycles + 1;
        end
        check(wait_cycles < 400_000, "program did not finish within 400k cycles (timeout)");
        $display("SHARED=%0d: program finished after %0d cycles, %0d vectors", SHARED, wait_cycles, N);
        repeat (2000) @(posedge clk);

        // ---------------- check ----------------
        for (i = 0; i < N; i = i + 1) begin
            check(rd_logical(32'h2000 + 4*i) === vE[i], "vector result mismatch");
            if (rd_logical(32'h2000 + 4*i) !== vE[i] && errors <= 40)
                $display("   vec %0d: A=%h B=%h ctrl=%0d got=%h exp=%h", i, vA[i], vB[i], vC[i],
                         rd_logical(32'h2000 + 4*i), vE[i]);
            // inputs must not have been corrupted by the program
            check(rd_logical(32'h1000 + 12*i + 0) === vA[i], "vector A corrupted in RAM");
            check(rd_logical(32'h1000 + 12*i + 4) === vB[i], "vector B corrupted in RAM");
        end
        // Status-poll behaviour, derived from NanoV's bit-serial load timing:
        //   A load streams rdata[counter] over 32 clocks, so BUSY (bit 0) and DONE (bit 1) are
        //   sampled at counters 0 and 1, i.e. 1-2 clocks after the START store.  The parallel
        //   variant (done 2 clocks after START edge) is seen complete on the first poll; the
        //   shared variant needs 4 compute clocks, so the first poll always reports not-done
        //   and the loop polls a second time.  The extra iteration is therefore EXPECTED for
        //   SHARED=1 and is asserted exactly (not removed): 2 polls/op vs 1 poll/op, plus one
        //   poll in the register-base path and one DONE-cleared check after CLR.
        $display("starts=%0d ctrl_reads=%0d max_busy_clocks=%0d clocks_from_start_to_status_read_end=%0d",
                 starts, ctrl_reads, max_busy_run, min_gap);
        check(starts == N + 1, "unexpected number of START strobes");
        check(ctrl_reads == (SHARED ? 2 : 1) * N + 2, "status poll count differs from bit-serial timing model");
        check(max_busy_run == (SHARED ? 4 : 1), "BUSY duration differs from architecture latency");
        check(min_gap == 32, "status load not sampled immediately after START as modelled");
        check(rd_logical(32'h1400) === vA[N-1], "DOT_A readback after compute");
        check(rd_logical(32'h1404) === vB[N-1], "DOT_B readback after compute");
        check(rd_logical(32'h1408) === model_dot(32'h01020304, 32'h05060708), "normal-path MMIO dot product");
        check(rd_logical(32'h140C) === 32'd0, "CLR did not clear result");
        check(rd_logical(32'h1410) === 32'd0, "CLR did not clear DONE");
        check(rd_logical(32'h1414) === 32'h0000006B, "GPIO_OUT readback alongside Dot4");
        check(rd_logical(32'h17FC) === 32'hC0DE600D, "end marker");
        check(gpio_out === 8'h6B, "final gpio_out");
        check(nh == 1 && hist[0] === 8'h6B, "unexpected GPIO_OUT activity");

        $display("checks=%0d errors=%0d", checks, errors);
        if (errors == 0 && checks > N) $display("RESULT: PASS");
        else                           $display("RESULT: FAIL");
        $finish;
    end
endmodule

`default_nettype wire
