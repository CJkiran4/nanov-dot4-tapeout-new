// Self-checking testbench for dot4_accel (shared- and parallel-multiplier variants).
// Expected values come from an independent behavioural model (integer maths),
// not from the DUT code.  Prints "RESULT: PASS" only when zero errors occurred.
`timescale 1ns/1ps
`default_nettype none

module tb_dot4_accel;
    reg         clk = 0;
    reg         rst_n = 0;
    reg         wr_a = 0, wr_b = 0, start = 0, acc_en = 0, clr = 0;
    reg  [31:0] wdata = 0;

    wire [31:0] a_s, b_s, res_s, a_p, b_p, res_p;
    wire        busy_s, done_s, busy_p, done_p;

    dot4_accel #(.SHARED(1)) dut_shared (
        .clk(clk), .rst_n(rst_n), .wr_a(wr_a), .wr_b(wr_b), .wdata(wdata),
        .start(start), .acc_en(acc_en), .clr(clr),
        .a_rd(a_s), .b_rd(b_s), .result(res_s), .busy(busy_s), .done(done_s));

    dot4_accel #(.SHARED(0)) dut_parallel (
        .clk(clk), .rst_n(rst_n), .wr_a(wr_a), .wr_b(wr_b), .wdata(wdata),
        .start(start), .acc_en(acc_en), .clr(clr),
        .a_rd(a_p), .b_rd(b_p), .result(res_p), .busy(busy_p), .done(done_p));

    always #5 clk = ~clk;

    integer errors = 0;
    integer checks = 0;

    task check(input cond, input [8*48-1:0] msg);
        begin
            checks = checks + 1;
            if (!cond) begin
                errors = errors + 1;
                if (errors <= 20) $display("FAIL @%0t: %0s", $time, msg);
            end
        end
    endtask

    // ---- independent reference model ----
    reg [31:0] model_acc;
    reg [31:0] model_a, model_b;

    function [31:0] model_dot(input [31:0] a, input [31:0] b);
        integer i;
        integer x, y, s;
        begin
            s = 0;
            for (i = 0; i < 4; i = i + 1) begin
                x = a[8*i +: 8];  if (x > 127) x = x - 256;   // sign-extend byte
                y = b[8*i +: 8];  if (y > 127) y = y - 256;
                s = s + x * y;
            end
            model_dot = s;
        end
    endfunction

    // ---- drive helpers: inputs change on negedge, DUT samples on posedge ----
    task write_a(input [31:0] v);
        begin @(negedge clk); wr_a = 1; wdata = v; @(negedge clk); wr_a = 0; model_a = v; end
    endtask
    task write_b(input [31:0] v);
        begin @(negedge clk); wr_b = 1; wdata = v; @(negedge clk); wr_b = 0; model_b = v; end
    endtask

    integer busy_cnt_s, busy_cnt_p, guard;

    // Issue start (optionally with acc/clr), optionally poke illegal writes while busy,
    // wait for both DUTs, check latency, result, done, and operand read-back.
    task run(input accumulate, input with_clr, input poke);
        reg [31:0] exp;
        begin
            @(negedge clk);
            start = 1; acc_en = accumulate; clr = with_clr;
            @(negedge clk);
            start = 0; acc_en = 0; clr = 0;
            if (with_clr) model_acc = 0;
            exp = (accumulate ? model_acc : 32'd0) + model_dot(model_a, model_b);

            check(busy_s === 1'b1 && busy_p === 1'b1, "busy not high after start");
            check(done_s === 1'b0 && done_p === 1'b0, "done not cleared by start");

            if (poke) begin
                // illegal activity while busy must be ignored
                wr_a = 1; wr_b = 1; start = 1; clr = 1; acc_en = 1; wdata = 32'hDEADBEEF;
                @(negedge clk);
                wr_a = 0; wr_b = 0; start = 0; clr = 0; acc_en = 0;
                busy_cnt_s = 1; busy_cnt_p = 1;   // already consumed one busy cycle in the poke
            end else begin
                busy_cnt_s = 0; busy_cnt_p = 0;
            end

            guard = 0;
            while ((busy_s || busy_p) && guard < 20) begin
                if (busy_s) busy_cnt_s = busy_cnt_s + 1;
                if (busy_p) busy_cnt_p = busy_cnt_p + 1;
                guard = guard + 1;
                @(negedge clk);
            end
            check(guard < 20, "timeout waiting for busy to drop");
            check(busy_cnt_s == 4, "shared latency != 4 busy cycles");
            check(busy_cnt_p == 1, "parallel latency != 1 busy cycle");
            check(done_s === 1'b1 && done_p === 1'b1, "done not set");
            check(res_s === exp, "shared result mismatch");
            check(res_p === exp, "parallel result mismatch");
            check(a_s === model_a && a_p === model_a, "operand A not preserved");
            check(b_s === model_b && b_p === model_b, "operand B not preserved");
            model_acc = exp;
        end
    endtask

    task vec(input [31:0] a, input [31:0] b, input accumulate);
        begin write_a(a); write_b(b); run(accumulate, 1'b0, 1'b0); end
    endtask

    integer i, k, n;
    reg [31:0] ra, rb;
    reg [31:0] sh_ref;
    reg [7:0]  lane;

    initial begin : watchdog
        #400_000_000;
        $display("FAIL: TIMEOUT (watchdog)");
        $display("RESULT: FAIL");
        $finish;
    end

    initial begin
        model_acc = 0; model_a = 0; model_b = 0;
        repeat (3) @(negedge clk);

        // ---- reset state ----
        check(busy_s === 0 && busy_p === 0 && done_s === 0 && done_p === 0, "reset: busy/done not 0");
        check(res_s === 32'd0 && res_p === 32'd0, "reset: result not 0");
        check(a_s === 32'd0 && b_s === 32'd0 && a_p === 32'd0 && b_p === 32'd0, "reset: operands not 0");
        rst_n = 1;
        @(negedge clk);

        // ---- directed vectors (non-accumulating) ----
        vec(32'h00000000, 32'h00000000, 0);
        vec(32'h80808080, 32'h80808080, 0);   // 4 * (-128 * -128) = 65536
        vec(32'h7F7F7F7F, 32'h7F7F7F7F, 0);   // 4 * 127*127 = 64516
        vec(32'h80808080, 32'h7F7F7F7F, 0);   // 4 * (-128*127) = -65024
        vec(32'hFFFFFFFF, 32'hFFFFFFFF, 0);   // 4 * 1 = 4
        vec(32'h01020304, 32'h05060708, 0);   // 70
        vec(32'h81FF027F, 32'h7F80FE81, 0);   // mixed signs
        // lane isolation: one non-zero lane at a time, other lanes carry big values in B only
        for (k = 0; k < 4; k = k + 1) begin
            ra = 32'd0; rb = 32'hFFFFFFFF;
            ra[8*k +: 8] = 8'd7;               // 7 * -1 = -7 in lane k only
            vec(ra, rb, 0);
            ra = 32'hFFFFFFFF; rb = 32'd0;
            rb[8*k +: 8] = 8'h80;              // -1 * -128 = 128 in lane k only
            vec(ra, rb, 0);
        end

        // ---- accumulate / clear ----
        write_a(32'h01010101); write_b(32'h02020202); run(0, 0, 0);          // 8
        write_a(32'h03030303); write_b(32'h04040404); run(1, 0, 0);          // +48 -> 56
        write_a(32'hFFFFFFFF); write_b(32'h01010101); run(1, 0, 0);          // -4 -> 52
        // clr + start + acc together: clr wins first, then accumulate onto 0
        write_a(32'h01010101); write_b(32'h01010101); run(1, 1, 0);          // 4
        check(res_s === 32'd4 && res_p === 32'd4, "clr+start+acc result");
        // clear command alone
        @(negedge clk); clr = 1; @(negedge clk); clr = 0; model_acc = 0;
        check(res_s === 32'd0 && res_p === 32'd0, "clr did not clear accumulator");
        check(done_s === 1'b0 && done_p === 1'b0, "clr did not clear done");

        // ---- illegal activity while busy is ignored ----
        write_a(32'h11223344); write_b(32'hFE05F0A1); run(0, 0, 1);
        write_a(32'h7F80017F); write_b(32'h80807F01); run(1, 0, 1);

        // ---- 32-bit accumulator wraparound: 65537 * 65536 mod 2^32 ----
        write_a(32'h80808080); write_b(32'h80808080); run(0, 0, 0);
        for (i = 0; i < 65536; i = i + 1) begin
            @(negedge clk); start = 1; acc_en = 1;
            @(negedge clk); start = 0; acc_en = 0;
            model_acc = model_acc + model_dot(32'h80808080, 32'h80808080);
            guard = 0;
            while ((busy_s || busy_p) && guard < 20) begin guard = guard + 1; @(negedge clk); end
        end
        check(res_s === model_acc && res_p === model_acc, "wraparound mismatch");
        check(res_s === 32'd65536, "wraparound value (65537*65536 mod 2^32 = 65536)");

        // ---- reset in the middle of an operation ----
        write_a(32'h12345678); write_b(32'h9ABCDEF0);
        @(negedge clk); start = 1; @(negedge clk); start = 0;
        check(busy_s === 1'b1, "shared should be busy before mid-op reset");
        rst_n = 0; @(negedge clk); rst_n = 1;
        check(busy_s === 0 && busy_p === 0 && done_s === 0 && done_p === 0, "mid-op reset: busy/done");
        check(res_s === 0 && res_p === 0 && a_s === 0 && b_s === 0, "mid-op reset: state not cleared");
        model_acc = 0; model_a = 0; model_b = 0;

        // ---- randomised (non-accumulating and accumulating mix) ----
        for (n = 0; n < 20000; n = n + 1) begin
            ra = $urandom; rb = $urandom;
            write_a(ra); write_b(rb);
            run(($urandom & 3) == 0, ($urandom & 15) == 0, ($urandom & 7) == 0);
        end

        // ---- extremes randomly: bytes limited to {-128, -1, 0, 1, 127} ----
        for (n = 0; n < 2000; n = n + 1) begin
            for (k = 0; k < 4; k = k + 1) begin
                case ($urandom % 5)
                    0: lane = 8'h80; 1: lane = 8'hFF; 2: lane = 8'h00; 3: lane = 8'h01; default: lane = 8'h7F;
                endcase
                ra[8*k +: 8] = lane;
                case ($urandom % 5)
                    0: lane = 8'h80; 1: lane = 8'hFF; 2: lane = 8'h00; 3: lane = 8'h01; default: lane = 8'h7F;
                endcase
                rb[8*k +: 8] = lane;
            end
            write_a(ra); write_b(rb); run(($urandom & 1), 1'b0, 1'b0);
        end

        repeat (4) @(negedge clk);
        $display("checks=%0d errors=%0d", checks, errors);
        if (errors == 0 && checks > 1000) $display("RESULT: PASS");
        else                              $display("RESULT: FAIL");
        $finish;
    end
endmodule

`default_nettype wire
