// Baseline regression + differential equivalence test.
//
//  DUT-A : unmodified upstream nanoV_top (ref_upstream/top.v, MichaelBell/nanoV e1a405e)
//  DUT-B : nanov_dot4_soc with ENABLE_DOT4=0 (this project's SoC without the accelerator)
//
// Both run sw/prog_baseline.mem against their own copy of the SPI RAM model.
//   1. Every SPI pin (select / clk / mosi) and the 8 GPIO outputs are compared
//      on both clock phases for the whole run.
//   2. After the program finishes, every result word in RAM is compared with a
//      value computed here with Verilog arithmetic (independent of the CPU).
//   3. The GPIO_OUT change history is compared with the expected sequence.
`timescale 1ns/1ps
`default_nettype none

module tb_nanov_baseline;
    reg clk = 0;
    reg rst_n = 0;
    always #40 clk = ~clk;                    // 12.5 MHz

    parameter PROG_FILE = "sw/prog_baseline.mem";   // see tb_nanov_dot4_system.v about relative paths
    localparam [2:0] GPIO_IN_VALUE = 3'b101;

    // ---------------- DUT-A: upstream nanoV_top ----------------
    wire a_miso, a_sel, a_sclk, a_mosi;
    wire [7:0] a_gpio;
    nanoV_top ref_top (
        .clk12MHz(clk), .rstn(rst_n),
        .spi_miso(a_miso), .spi_select(a_sel), .spi_clk_out(a_sclk), .spi_mosi(a_mosi),
        .uart_rxd(1'b1), .uart_txd(), .uart_rts(),
        .button1(GPIO_IN_VALUE[0]), .button2(GPIO_IN_VALUE[1]), .button3(GPIO_IN_VALUE[2]),
        .out0(a_gpio[0]), .out1(a_gpio[1]), .out2(a_gpio[2]), .out3(a_gpio[3]),
        .out4(a_gpio[4]), .out5(a_gpio[5]), .out6(a_gpio[6]), .out7(a_gpio[7]),
        .led1(), .led2(), .led3(), .led4(), .led5(), .led6(), .led7(), .led8(),
        .lcol1(), .lcol2(), .lcol3(), .lcol4(), .spkp(), .spkm());

    sim_spi_ram #(.INIT_FILE(PROG_FILE)) ram_a (
        .spi_clk(a_sclk), .spi_mosi(a_mosi), .spi_select(a_sel), .spi_miso(a_miso),
        .debug_clk(1'b0), .debug_addr(24'd0), .debug_data());

    // ---------------- DUT-B: this project's SoC, Dot4 disabled ----------------
    wire b_miso, b_sel, b_sclk, b_mosi;
    wire [7:0] b_gpio;
    nanov_dot4_soc #(.ENABLE_DOT4(0), .DOT4_SHARED(1)) dut_b (
        .clk(clk), .rst_n(rst_n),
        .spi_miso(b_miso), .spi_select(b_sel), .spi_clk_out(b_sclk), .spi_mosi(b_mosi),
        .gpio_in(GPIO_IN_VALUE), .gpio_out(b_gpio));

    sim_spi_ram #(.INIT_FILE(PROG_FILE)) ram_b (
        .spi_clk(b_sclk), .spi_mosi(b_mosi), .spi_select(b_sel), .spi_miso(b_miso),
        .debug_clk(1'b0), .debug_addr(24'd0), .debug_data());

    // ---------------- bookkeeping ----------------
    integer errors = 0, checks = 0, mismatches = 0;
    task check(input cond, input [8*60-1:0] msg);
        begin
            checks = checks + 1;
            if (!cond) begin
                errors = errors + 1;
                if (errors <= 40) $display("FAIL @%0t: %0s", $time, msg);
            end
        end
    endtask

    // Cycle-accurate differential comparison on both clock phases.
    reg compare_en = 0;
    integer compared = 0;
    always @(clk) begin
        #2;
        if (compare_en) begin
            compared = compared + 1;
            if (a_sel !== b_sel || a_sclk !== b_sclk || a_mosi !== b_mosi || a_gpio !== b_gpio) begin
                mismatches = mismatches + 1;
                if (mismatches <= 5)
                    $display("DIFF @%0t: sel %b/%b sclk %b/%b mosi %b/%b gpio %h/%h",
                             $time, a_sel, b_sel, a_sclk, b_sclk, a_mosi, b_mosi, a_gpio, b_gpio);
            end
        end
    end

    // GPIO_OUT change history for both DUTs.
    reg [7:0] hist_a [0:15], hist_b [0:15];
    integer na = 0, nb = 0;
    always @(a_gpio) if (rst_n && compare_en && na < 16) begin hist_a[na] = a_gpio; na = na + 1; end
    always @(b_gpio) if (rst_n && compare_en && nb < 16) begin hist_b[nb] = b_gpio; nb = nb + 1; end

    // ---------------- expected values (independent of the CPU) ----------------
    localparam [31:0] RES_BASE_WORD = 32'h1000 >> 2;

    // The SPI RAM model holds the physical memory image: NanoV streams data
    // LSB-first but a SPI memory serves each byte MSB-first, so every byte in the
    // array is bit-reversed relative to the CPU's logical value.
    function [31:0] brev8(input [31:0] w);
        integer bi;
        begin
            for (bi = 0; bi < 32; bi = bi + 1)
                brev8[(bi / 8) * 8 + (7 - (bi % 8))] = w[bi];
        end
    endfunction
    function [31:0] word_a(input [31:0] off);
        word_a = brev8(ram_a.data[RES_BASE_WORD + (off >> 2)]);
    endfunction
    function [31:0] word_b(input [31:0] off);
        word_b = brev8(ram_b.data[RES_BASE_WORD + (off >> 2)]);
    endfunction

    task expect_word(input [31:0] off, input [31:0] exp, input [8*28-1:0] name);
        reg [31:0] ga, gb;
        begin
            ga = word_a(off); gb = word_b(off);
            checks = checks + 2;
            if (ga !== exp) begin
                errors = errors + 1;
                $display("FAIL: [upstream top] %0s @+%h = %h, expected %h", name, off, ga, exp);
            end
            if (gb !== exp) begin
                errors = errors + 1;
                $display("FAIL: [project SoC ] %0s @+%h = %h, expected %h", name, off, gb, exp);
            end
        end
    endtask

    reg [31:0] x0v, x1v, br_mask, loop_sum;
    integer li;
    reg signed [31:0] s_neg5, s_min, s_m3, s_m7;

    initial begin : watchdog
        #40_000_000;
        $display("FAIL: TIMEOUT (watchdog) - marker word never written");
        $display("RESULT: FAIL");
        $finish;
    end

    integer wait_cycles;
    initial begin
        #1;
        if (ram_a.data[0] === 32'd0 || ram_b.data[0] === 32'd0) begin
            $display("FAIL: program image not loaded from \"%0s\" - word 0 is zero. Check the path / copy the .mem into the simulator run folder.", PROG_FILE);
            $display("RESULT: FAIL");
            $finish;
        end
        rst_n = 0;
        repeat (4) @(posedge clk);
        @(negedge clk); rst_n = 1;
        compare_en = 1;

        // wait for the end-of-program marker (both DUTs), explicit cycle limit
        wait_cycles = 0;
        while (!(word_a(32'h3fc) === 32'hC0DE600D && word_b(32'h3fc) === 32'hC0DE600D) && wait_cycles < 200_000) begin
            @(posedge clk);
            wait_cycles = wait_cycles + 1;
        end
        check(wait_cycles < 200_000, "program did not finish within 200k cycles (timeout)");
        $display("program finished after %0d cycles", wait_cycles);
        repeat (2000) @(posedge clk);          // let the tail of the SPI traffic play out
        compare_en = 0;

        // ---- differential result ----
        check(mismatches == 0, "pin-level mismatch between upstream top and project SoC");
        check(compared >= 2 * wait_cycles, "differential comparison did not cover the whole run");

        // ---- expected values ----
        x0v = 32'h12345678; x1v = 32'h0F0F0F0F;
        s_neg5 = -5; s_min = 32'h80000000; s_m3 = -3; s_m7 = -7;
        expect_word(32'h200, x0v + x1v,                       "add");
        expect_word(32'h204, x0v - x1v,                       "sub");
        expect_word(32'h208, x0v & x1v,                       "and");
        expect_word(32'h20c, x0v | x1v,                       "or");
        expect_word(32'h210, x0v ^ x1v,                       "xor");
        expect_word(32'h214, x0v << 5,                        "sll");
        expect_word(32'h218, x0v >> 5,                        "srl");
        expect_word(32'h21c, s_min >>> 5,                     "sra");
        expect_word(32'h220, (s_neg5 < 3) ? 32'd1 : 32'd0,    "slt");
        expect_word(32'h224, (32'hFFFFFFFB < 32'd3) ? 32'd1 : 32'd0, "sltu");
        expect_word(32'h228, x0v << 4,                        "slli");
        expect_word(32'h22c, x0v >> 4,                        "srli");
        expect_word(32'h230, s_min >>> 1,                     "srai");
        expect_word(32'h234, x0v * 32'h0000BEEF,              "mul (rs2[15:0])");
        expect_word(32'h24c, x0v * 32'h00000003,              "mul ignores rs2[31:16]");

        br_mask = 0;
        if (32'd5 == 32'd5)                       br_mask = br_mask | 32'h001;  // beq a0,a1
        if (32'd5 != 32'd5)                       br_mask = br_mask | 32'h002;  // bne a0,a1
        if (s_m3 < $signed(32'd5))                br_mask = br_mask | 32'h004;  // blt a3,a0
        if ($signed(32'd5) >= s_m3)               br_mask = br_mask | 32'h008;  // bge a0,a3
        if (32'd5 < 32'hFFFFFFFD)                 br_mask = br_mask | 32'h010;  // bltu a0,a3
        if (32'hFFFFFFFD >= 32'd5)                br_mask = br_mask | 32'h020;  // bgeu a3,a0
        if ($signed(32'd5) < s_m3)                br_mask = br_mask | 32'h040;  // blt a0,a3
        if (32'd5 != 32'd7)                       br_mask = br_mask | 32'h080;  // bne a0,a4
        if (32'd5 == 32'd7)                       br_mask = br_mask | 32'h100;  // beq a0,a4
        if (32'd5 >= 32'hFFFFFFFD)                br_mask = br_mask | 32'h200;  // bgeu a0,a3
        expect_word(32'h238, br_mask,                         "branch mask");

        loop_sum = 0;
        for (li = 1; li <= 10; li = li + 1) loop_sum = loop_sum + li;
        expect_word(32'h23c, loop_sum,                        "loop sum 1..10");
        expect_word(32'h240, 32'd42,                          "jal/jalr double");
        expect_word(32'h244, 32'd4,                           "auipc delta");
        expect_word(32'h248, 32'hABCDE000,                    "lui");
        expect_word(32'h250, (s_m7 < -3) ? 32'd1 : 32'd0,     "slti");
        expect_word(32'h254, (32'hFFFFFFF9 < 32'd5) ? 32'd1 : 32'd0, "sltiu");
        expect_word(32'h258, 32'h0000FFFF & 32'h000007F0,     "andi");
        expect_word(32'h25c, 32'h0000FFFF | 32'h00000700,     "ori");
        expect_word(32'h260, 32'h0000FFFF ^ 32'hFFFFFFFF,     "xori");
        expect_word(32'h264, 32'h0000FFFF - 32'd256,          "addi negative");

        expect_word(32'h310, 32'hFFFFFFEF,                    "lb");
        expect_word(32'h314, 32'h000000EF,                    "lbu");
        expect_word(32'h318, 32'hFFFF89AB,                    "lh");
        expect_word(32'h31c, 32'h000089AB,                    "lhu");
        expect_word(32'h320, 32'h00005A00,                    "sb merge");
        expect_word(32'h324, 32'hBEEF5A00,                    "sh merge");
        expect_word(32'h380, 32'h89ABCDEF,                    "raw stored word");

        expect_word(32'h340, 32'h000000A5,                    "GPIO_OUT readback (fast)");
        expect_word(32'h344, {29'd0, GPIO_IN_VALUE},          "GPIO_IN read");
        expect_word(32'h348, 32'h0000003C,                    "GPIO_OUT readback (normal)");
        expect_word(32'h34c, 32'h00000000,                    "unmapped read");
        expect_word(32'h350, 32'h0000003C,                    "unmapped write ignored");
        expect_word(32'h3fc, 32'hC0DE600D,                    "end marker");

        // ---- GPIO output history: 0x5A, 0xA5, 0x3C ----
        check(na == 3 && nb == 3, "GPIO_OUT change count != 3");
        check(hist_a[0] === 8'h5A && hist_a[1] === 8'hA5 && hist_a[2] === 8'h3C, "upstream GPIO history");
        check(hist_b[0] === 8'h5A && hist_b[1] === 8'hA5 && hist_b[2] === 8'h3C, "project SoC GPIO history");
        check(a_gpio === 8'h3C && b_gpio === 8'h3C, "final GPIO_OUT value");

        $display("compared %0d samples, mismatches=%0d, checks=%0d errors=%0d", compared, mismatches, checks, errors);
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL");
        $finish;
    end
endmodule

`default_nettype wire
