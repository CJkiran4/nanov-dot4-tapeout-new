// Self-checking testbench for nanov_mmio_decoder.
// Drives the NanoV peripheral protocol (store_addr_out / store_data_out) by hand
// and compares against explicit expectations.  Two instances run side by side:
// ENABLE_DOT4=1 and ENABLE_DOT4=0.
`timescale 1ns/1ps
`default_nettype none

module tb_mmio_decoder;
    reg         clk = 0;
    reg         rst_n = 0;
    reg         addr_valid = 0, data_valid = 0;
    reg  [31:0] addr = 0, wdata = 0;
    reg  [2:0]  gpio_in = 0;

    reg  [31:0] dot_a_rd = 32'hA0A1A2A3, dot_b_rd = 32'hB0B1B2B3, dot_result = 32'hFEEDC0DE;
    reg         dot_busy = 0, dot_done = 0;

    // ENABLE_DOT4 = 1
    wire [7:0]  gpio_out_1;
    wire [31:0] rdata_1;
    wire        wr_a_1, wr_b_1, start_1, acc_1, clr_1;
    nanov_mmio_decoder #(.ENABLE_DOT4(1)) dut1 (
        .clk(clk), .rst_n(rst_n),
        .addr_valid(addr_valid), .addr(addr), .data_valid(data_valid), .wdata(wdata),
        .gpio_in(gpio_in), .gpio_out(gpio_out_1), .rdata(rdata_1),
        .dot_wr_a(wr_a_1), .dot_wr_b(wr_b_1), .dot_start(start_1), .dot_acc(acc_1), .dot_clr(clr_1),
        .dot_a_rd(dot_a_rd), .dot_b_rd(dot_b_rd), .dot_result(dot_result),
        .dot_busy(dot_busy), .dot_done(dot_done));

    // ENABLE_DOT4 = 0
    wire [7:0]  gpio_out_0;
    wire [31:0] rdata_0;
    wire        wr_a_0, wr_b_0, start_0, acc_0, clr_0;
    nanov_mmio_decoder #(.ENABLE_DOT4(0)) dut0 (
        .clk(clk), .rst_n(rst_n),
        .addr_valid(addr_valid), .addr(addr), .data_valid(data_valid), .wdata(wdata),
        .gpio_in(gpio_in), .gpio_out(gpio_out_0), .rdata(rdata_0),
        .dot_wr_a(wr_a_0), .dot_wr_b(wr_b_0), .dot_start(start_0), .dot_acc(acc_0), .dot_clr(clr_0),
        .dot_a_rd(dot_a_rd), .dot_b_rd(dot_b_rd), .dot_result(dot_result),
        .dot_busy(dot_busy), .dot_done(dot_done));

    always #5 clk = ~clk;

    integer errors = 0, checks = 0;
    task check(input cond, input [8*56-1:0] msg);
        begin
            checks = checks + 1;
            if (!cond) begin
                errors = errors + 1;
                if (errors <= 30) $display("FAIL @%0t: %0s", $time, msg);
            end
        end
    endtask

    localparam [31:0] A_GPIO_OUT = 32'h10000000, A_GPIO_IN = 32'h10000004,
                      A_DOT_A = 32'h10000100, A_DOT_B = 32'h10000104,
                      A_DOT_CTRL = 32'h10000108, A_DOT_RES = 32'h1000010C;

    // Address phase: valid for one clock; afterwards the bus carries a decoy
    // address that would select GPIO_OUT, which must be ignored (valid=0).
    task send_addr(input [31:0] a);
        begin
            @(negedge clk); addr_valid = 1; addr = a;
            @(negedge clk); addr_valid = 0; addr = A_GPIO_OUT;
        end
    endtask

    // Data phase: strobes are combinational on the registered selection, so look
    // at them while data_valid is high (before the capturing clock edge).
    reg s_a1, s_b1, s_st1, s_acc1, s_clr1, s_a0, s_b0, s_st0, s_clr0;
    task send_data(input [31:0] w);
        begin
            @(negedge clk); data_valid = 1; wdata = w;
            #1;
            s_a1 = wr_a_1; s_b1 = wr_b_1; s_st1 = start_1; s_acc1 = acc_1; s_clr1 = clr_1;
            s_a0 = wr_a_0; s_b0 = wr_b_0; s_st0 = start_0; s_clr0 = clr_0;
            @(negedge clk); data_valid = 0; wdata = 32'hFFFFFFFF;
        end
    endtask

    integer i;
    reg [7:0] exp_gpio;

    initial begin : watchdog
        #5_000_000;
        $display("FAIL: TIMEOUT (watchdog)");
        $display("RESULT: FAIL");
        $finish;
    end

    initial begin
        repeat (3) @(negedge clk);
        // ---- in reset ----
        check(gpio_out_1 === 8'd0 && gpio_out_0 === 8'd0, "reset: gpio_out not 0");
        check(rdata_1 === 32'd0 && rdata_0 === 32'd0, "reset: rdata not 0");
        rst_n = 1;
        @(negedge clk);

        // ---- strobes are low with no selection ----
        check(!wr_a_1 && !wr_b_1 && !start_1 && !clr_1, "idle: strobes must be low");

        // ---- GPIO_OUT write / readback / masking ----
        send_addr(A_GPIO_OUT);
        send_data(32'h000001A5);                         // bit 8 must be dropped
        check(gpio_out_1 === 8'hA5 && gpio_out_0 === 8'hA5, "GPIO_OUT write 0x1A5 -> 0xA5");
        check(rdata_1 === 32'h000000A5 && rdata_0 === 32'h000000A5, "GPIO_OUT readback");
        check(!s_a1 && !s_b1 && !s_st1 && !s_clr1, "GPIO write must not strobe Dot4");
        // data_valid=0 with addr bus decoy: gpio_out unchanged
        @(negedge clk); wdata = 32'h55; @(negedge clk); wdata = 32'hFFFFFFFF;
        check(gpio_out_1 === 8'hA5, "no write without data_valid");

        // ---- GPIO_IN read, all 8 input values ----
        send_addr(A_GPIO_IN);
        for (i = 0; i < 8; i = i + 1) begin
            gpio_in = i[2:0]; #1;
            check(rdata_1 === {29'd0, i[2:0]} && rdata_0 === {29'd0, i[2:0]}, "GPIO_IN readback");
        end
        // writing GPIO_IN address must not change gpio_out
        send_data(32'hFF);
        check(gpio_out_1 === 8'hA5, "write to GPIO_IN must be ignored");

        // ---- registered selection: new address in the same clock as previous data ----
        send_addr(A_DOT_A);
        @(negedge clk);
        addr_valid = 1; addr = A_GPIO_OUT;               // next instruction's address...
        data_valid = 1; wdata = 32'h12345678;            // ...arrives with previous store's data
        #1;
        check(wr_a_1 === 1'b1, "same-clock addr+data: write must hit old selection (DOT_A)");
        check(wr_a_0 === 1'b0, "ENABLE_DOT4=0: DOT_A strobe must stay low");
        @(negedge clk);
        addr_valid = 0; data_valid = 0; addr = A_DOT_B; wdata = 32'hFFFFFFFF;
        check(gpio_out_1 === 8'hA5, "GPIO_OUT must not capture previous store's data");
        send_data(32'h000000C3);                         // now selected: GPIO_OUT
        check(gpio_out_1 === 8'hC3 && gpio_out_0 === 8'hC3, "GPIO_OUT after address handover");

        // ---- Dot4 strobes ----
        send_addr(A_DOT_A);
        send_data(32'h01020304);
        check(s_a1 && !s_b1 && !s_st1 && !s_clr1, "DOT_A write strobes only wr_a");
        check(!s_a0 && !s_b0 && !s_st0 && !s_clr0, "ENABLE_DOT4=0: no strobes on DOT_A");
        send_addr(A_DOT_B);
        send_data(32'h05060708);
        check(!s_a1 && s_b1 && !s_st1 && !s_clr1, "DOT_B write strobes only wr_b");
        // selection active but data_valid low: strobes stay low
        #1;
        check(!wr_a_1 && !wr_b_1 && !start_1 && !clr_1, "strobes low when data_valid low");

        // ---- DOT_CTRL bit decode: START=bit0 ACC=bit1 CLR=bit2 ----
        send_addr(A_DOT_CTRL);
        for (i = 0; i < 8; i = i + 1) begin
            send_data({29'd0, i[2:0]});
            check(s_st1 === i[0] && s_acc1 === i[1] && s_clr1 === i[2], "DOT_CTRL bit decode");
            check(!s_a1 && !s_b1, "DOT_CTRL must not strobe operand writes");
            check(!s_st0 && !s_clr0, "ENABLE_DOT4=0: DOT_CTRL inert");
        end
        send_data(32'hFFFFFFF8);                          // only reserved bits set
        check(!s_st1 && !s_clr1, "reserved CTRL bits must not trigger");

        // ---- Dot4 read-back mux ----
        send_addr(A_DOT_A);   #1; check(rdata_1 === 32'hA0A1A2A3, "read DOT_A");
        check(rdata_0 === 32'd0, "ENABLE_DOT4=0: DOT_A reads 0");
        send_addr(A_DOT_B);   #1; check(rdata_1 === 32'hB0B1B2B3, "read DOT_B");
        send_addr(A_DOT_RES); #1; check(rdata_1 === 32'hFEEDC0DE, "read DOT_RESULT");
        check(rdata_0 === 32'd0, "ENABLE_DOT4=0: DOT_RESULT reads 0");
        send_addr(A_DOT_CTRL);
        dot_busy = 0; dot_done = 0; #1; check(rdata_1 === 32'd0, "CTRL read idle");
        dot_busy = 1; dot_done = 0; #1; check(rdata_1 === 32'd1, "CTRL read busy");
        dot_busy = 0; dot_done = 1; #1; check(rdata_1 === 32'd2, "CTRL read done");
        dot_busy = 1; dot_done = 1; #1; check(rdata_1 === 32'd3, "CTRL read busy+done");
        check(rdata_0 === 32'd0, "ENABLE_DOT4=0: CTRL reads 0");
        dot_busy = 0; dot_done = 0;

        // ---- unmapped / near-miss addresses: read 0, writes ignored ----
        begin : unmapped
            reg [31:0] bad [0:11];
            integer j;
            bad[0]  = 32'h10000008;  bad[1]  = 32'h10000010; bad[2]  = 32'h10000014;
            bad[3]  = 32'h10000020;  bad[4]  = 32'h00000000; bad[5]  = 32'h10000101;
            bad[6]  = 32'h90000100;  bad[7]  = 32'h10000110; bad[8]  = 32'h10000200;
            bad[9]  = 32'h11000000;  bad[10] = 32'h10000001; bad[11] = 32'h0000010C;
            for (j = 0; j < 12; j = j + 1) begin
                send_addr(bad[j]);
                #1;
                check(rdata_1 === 32'd0 && rdata_0 === 32'd0, "unmapped address must read 0");
                send_data(32'h000000FF);
                check(!s_a1 && !s_b1 && !s_st1 && !s_clr1, "unmapped write must not strobe");
                check(gpio_out_1 === 8'hC3 && gpio_out_0 === 8'hC3, "unmapped write must not change GPIO_OUT");
            end
        end

        // ---- ENABLE_DOT4=0 still has working GPIO ----
        send_addr(A_GPIO_OUT); send_data(32'h0000007E);
        check(gpio_out_0 === 8'h7E && gpio_out_1 === 8'h7E, "GPIO write on both instances");

        // ---- reset clears selection and GPIO_OUT ----
        rst_n = 0; @(negedge clk); rst_n = 1; @(negedge clk);
        check(gpio_out_1 === 8'd0 && gpio_out_0 === 8'd0, "reset clears GPIO_OUT");
        check(rdata_1 === 32'd0, "reset clears selection");
        send_data(32'h000000FF);                          // sel = NONE after reset
        check(gpio_out_1 === 8'd0, "write after reset with no address must be ignored");

        // ---- randomised protocol sequence vs. an independent scoreboard ----
        begin : random_phase
            integer n, pick;
            reg [31:0] cand [0:15];
            reg [2:0]  m_sel1, m_sel0;     // model selection: 0 none,1 gout,2 gin,3 A,4 B,5 CTRL,6 RES
            reg [7:0]  m_gpio;
            reg [31:0] m_rd1, m_rd0, rnd;
            cand[0]  = A_GPIO_OUT; cand[1]  = A_GPIO_IN; cand[2]  = A_DOT_A;  cand[3]  = A_DOT_B;
            cand[4]  = A_DOT_CTRL; cand[5]  = A_DOT_RES; cand[6]  = 32'h10000008; cand[7]  = 32'h10000010;
            cand[8]  = 32'h10000020; cand[9] = 32'h10000101; cand[10] = 32'h90000100; cand[11] = 32'h00000104;
            cand[12] = 32'h10000300; cand[13] = 32'h10000000 | 32'h00010000; cand[14] = 32'h10000104 ^ 32'h2; cand[15] = 32'h10000108 | 32'h80000000;
            rst_n = 0; @(negedge clk); rst_n = 1; @(negedge clk);
            m_sel1 = 0; m_sel0 = 0; m_gpio = 0;
            for (n = 0; n < 3000; n = n + 1) begin
                pick = $urandom % 4;
                if (pick == 0) begin
                    rnd = cand[$urandom % 16];
                    send_addr(rnd);
                    // independent address decode
                    m_sel1 = 0; m_sel0 = 0;
                    if (rnd == 32'h10000000) begin m_sel1 = 1; m_sel0 = 1; end
                    if (rnd == 32'h10000004) begin m_sel1 = 2; m_sel0 = 2; end
                    if (rnd == 32'h10000100) m_sel1 = 3;
                    if (rnd == 32'h10000104) m_sel1 = 4;
                    if (rnd == 32'h10000108) m_sel1 = 5;
                    if (rnd == 32'h1000010C) m_sel1 = 6;
                end else if (pick == 1) begin
                    rnd = $urandom;
                    send_data(rnd);
                    if (m_sel1 == 1) m_gpio = rnd[7:0];
                    check(s_a1 === (m_sel1 == 3), "rand: wr_a strobe");
                    check(s_b1 === (m_sel1 == 4), "rand: wr_b strobe");
                    check(s_st1 === (m_sel1 == 5 && rnd[0]), "rand: start strobe");
                    check(s_clr1 === (m_sel1 == 5 && rnd[2]), "rand: clr strobe");
                    check(!s_a0 && !s_b0 && !s_st0 && !s_clr0, "rand: ENABLE_DOT4=0 strobes");
                    #1;
                    check(gpio_out_1 === m_gpio, "rand: gpio_out (Dot4 enabled)");
                    check(gpio_out_0 === m_gpio, "rand: gpio_out (Dot4 disabled)");
                end else begin
                    gpio_in = $urandom; dot_busy = $urandom; dot_done = $urandom;
                    dot_a_rd = $urandom; dot_b_rd = $urandom; dot_result = $urandom;
                    #1;
                    case (m_sel1)
                        1: m_rd1 = {24'd0, m_gpio};
                        2: m_rd1 = {29'd0, gpio_in};
                        3: m_rd1 = dot_a_rd;
                        4: m_rd1 = dot_b_rd;
                        5: m_rd1 = {30'd0, dot_done, dot_busy};
                        6: m_rd1 = dot_result;
                        default: m_rd1 = 32'd0;
                    endcase
                    case (m_sel0)
                        1: m_rd0 = {24'd0, gpio_out_0};
                        2: m_rd0 = {29'd0, gpio_in};
                        default: m_rd0 = 32'd0;
                    endcase
                    check(rdata_1 === m_rd1, "rand: rdata (Dot4 enabled)");
                    check(rdata_0 === m_rd0, "rand: rdata (Dot4 disabled)");
                end
            end
        end

        $display("checks=%0d errors=%0d", checks, errors);
        if (errors == 0 && checks > 100) $display("RESULT: PASS");
        else                             $display("RESULT: FAIL");
        $finish;
    end
endmodule

`default_nettype wire
