// Board-level test of zedboard_nanov_dot4_top (INTERNAL_MEM=1): the demo program in on-chip block RAM runs by
// itself; SW[2:0] selects a vector, LD[7:0] must show the low byte of dot4(A,B).  Uses the behavioural MMCM stub
// (fpga/sim/unisim_stubs.v).  Expected LED values are computed HERE from A and B with signed arithmetic - they are
// not read from the program's table.  BAD_IDX >= 0 is a negative control: the image was built with a wrong
// expected word for that vector, so the program must show 0xFF there.
`timescale 1ns/1ps
`default_nettype none
module tb_board_demo;
    parameter SHARED  = 1;
    parameter BAD_IDX = -1;

    reg GCLK = 0;  always #5 GCLK = ~GCLK;           // 100 MHz
    reg BTNC = 1;
    reg [2:0] SW = 3'b000;
    wire [7:0] LD;
    wire JA1, JA2, JA4;

    zedboard_nanov_dot4_top #(.DOT4_SHARED(SHARED), .INTERNAL_MEM(1)) dut (
        .GCLK(GCLK), .BTNC(BTNC), .SW(SW), .LD(LD), .JA1(JA1), .JA2(JA2), .JA3(1'b0), .JA4(JA4));

    reg [31:0] VA [0:7];
    reg [31:0] VB [0:7];
    initial begin
        VA[0]=32'h01010101; VB[0]=32'h01010101;
        VA[1]=32'h01020304; VB[1]=32'h05060708;
        VA[2]=32'h0a0a0a0a; VB[2]=32'h01020304;
        VA[3]=32'hfffefdfc; VB[3]=32'h01010101;
        VA[4]=32'h7f7f7f7f; VB[4]=32'h01010101;
        VA[5]=32'h00000080; VB[5]=32'h00000001;
        VA[6]=32'h12345678; VB[6]=32'h01010101;
        VA[7]=32'h0f0f0f0f; VB[7]=32'h02020202;
    end

    function integer s8(input [7:0] b); s8 = b[7] ? $signed({24'hffffff, b}) : $signed({24'h0, b}); endfunction
    function [7:0] exp_led(input integer i);
        integer k, acc;
        begin
            acc = 0;
            for (k = 0; k < 4; k = k + 1) acc = acc + s8(VA[i] >> (8*k)) * s8(VB[i] >> (8*k));
            exp_led = (i == BAD_IDX) ? 8'hFF : acc[7:0];
        end
    endfunction

    integer errors = 0, checks = 0;
    task check(input c, input [8*64-1:0] m);
        begin checks = checks + 1; if (!c) begin errors = errors + 1; $display("FAIL @%0t: %0s (LD=%b SW=%b)", $time, m, LD, SW); end end
    endtask

    reg started = 0;
    always @(LD) if (started && (^LD === 1'bx)) begin errors = errors + 1; $display("FAIL: X on LD"); end

    initial begin : watchdog #60_000_000; $display("FAIL: TIMEOUT"); $display("RESULT: FAIL"); $finish; end

    integer n, idx, pass, seed;
    task show(input integer i);
        begin
            SW = i[2:0];
            n = 0;
            while (LD !== exp_led(i) && n < 400_000) begin @(posedge GCLK); n = n + 1; end
            check(LD === exp_led(i), "LED did not reach the expected value (timeout)");
            repeat (6000) @(posedge GCLK);                       // stays there, no glitching to another value
            check(LD === exp_led(i), "LED value not stable");
        end
    endtask

    initial begin
        #200 BTNC = 0;
        started = 1;
        for (idx = 0; idx < 8; idx = idx + 1) show(idx);                     // ascending
        for (idx = 7; idx >= 0; idx = idx - 1) show(idx);                    // descending
        seed = 32'h1234;
        for (pass = 0; pass < 24; pass = pass + 1) show($unsigned($random(seed)) % 8);   // random order
        // BTNC reset: LEDs cleared, program restarts and shows the same value again
        SW = 3'd4;
        BTNC = 1; repeat (200) @(posedge GCLK);
        check(LD === 8'h00, "BTNC reset did not clear LD");
        BTNC = 0;
        show(4);
        // the SPI mirror pins on JA must be idle-high CS or toggling, never X
        check(^{JA1, JA2, JA4} !== 1'bx, "X on JA pins");
        $display("SHARED=%0d BAD_IDX=%0d: checks=%0d errors=%0d  LD final=%b", SHARED, BAD_IDX, checks, errors, LD);
        if (errors == 0) $display("RESULT: PASS"); else $display("RESULT: FAIL");
        $finish;
    end
endmodule
`default_nettype wire
