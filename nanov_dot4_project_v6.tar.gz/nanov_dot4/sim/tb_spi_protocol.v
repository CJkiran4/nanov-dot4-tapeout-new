// Protocol check on the bare, unmodified upstream nanoV_cpu (no RAM model, no image).
//   * After reset the CPU must send READ (0x03) then a 24-bit address 0, MSB first.
//   * Instruction words returned LSB-first (exactly how upstream test_cpu.py's
//     send_instr drives spi_data_in) must execute:
//         addi t0, x0, 0x55 ; sw t0, 0x100(tp)  -> store address 0x10000100, data 0x55
//   * Returning the same bytes with each byte's bits MSB-first (what a standard SPI
//     memory serves from an un-reversed image) must NOT produce that store.
// This is what fixes the memory-image convention: a standard SPI memory serves each
// byte MSB-first, NanoV consumes LSB-first, so the stored image has bit-reversed bytes.
`timescale 1ns/1ps
`default_nettype none
module tb_spi_protocol;
    reg clk = 0, rst_n = 0;
    always #5 clk = ~clk;

    reg  [1:0] mode_unused = 0;
    // two CPUs: A fed LSB-first, B fed byte-wise MSB-first
    reg  din_a = 0, din_b = 0;
    wire sel_a, out_a, en_a, sel_b, out_b, en_b;
    wire [31:0] addr_a, data_a, addr_b, data_b;
    wire sd_a, sa_a, rd_a, sd_b, sa_b, rd_b;
    nanoV_cpu cpu_a (clk, rst_n, din_a, sel_a, out_a, en_a, 32'd0, addr_a, data_a, sd_a, sa_a, rd_a);
    nanoV_cpu cpu_b (clk, rst_n, din_b, sel_b, out_b, en_b, 32'd0, addr_b, data_b, sd_b, sa_b, rd_b);

    integer errors = 0;
    task check(input c, input [8*64-1:0] m);
        begin if (!c) begin errors = errors + 1; $display("FAIL: %0s", m); end end
    endtask

    localparam [31:0] I_ADDI = 32'h05500293;   // addi t0,x0,0x55
    localparam [31:0] I_SW   = 32'h10522023;   // sw   t0,0x100(tp)
    localparam [31:0] I_NOP  = 32'h00000013;
    reg [31:0] prog [0:7];

    reg got_a = 0, got_b = 0; reg [31:0] gaddr_a, gdata_a;
    reg seen_addr_a = 0, seen_addr_b = 0;
    always @(posedge clk) begin
        if (sa_a && addr_a == 32'h10000100) seen_addr_a <= 1;
        if (sd_a && seen_addr_a) begin got_a <= 1; gdata_a <= data_a; end
        if (sa_b && addr_b == 32'h10000100) seen_addr_b <= 1;
        if (sd_b && seen_addr_b) got_b <= 1;
    end

    function bitof(input [31:0] w, input integer i, input integer msb_first);
        begin bitof = msb_first ? w[(i/8)*8 + 7 - (i%8)] : w[i]; end
    endfunction

    integer i, w, cmdbits;
    reg [31:0] cmd;
    initial begin : watchdog #2_000_000; $display("FAIL: TIMEOUT"); $display("RESULT: FAIL"); $finish; end

    initial begin
        prog[0]=I_ADDI; prog[1]=I_SW; for (w=2; w<8; w=w+1) prog[w]=I_NOP;
        repeat (2) @(posedge clk);
        @(negedge clk); rst_n = 1;
        // wait for chip select (cpu_a and cpu_b are identical in the command phase)
        cmd = 0; cmdbits = 0;
        while (sel_a !== 1'b0) @(posedge clk);
        // command + address phase: 32 clocks, sample just before each edge
        for (i = 0; i < 32; i = i + 1) begin
            @(posedge clk);
            check(sel_a === 1'b0, "select must stay low during command/address");
        end
        // (re-run bit capture properly below via a second pass would be redundant;
        //  the capture is done by the monitor block)
        // instruction phase
        for (w = 0; w < 8; w = w + 1) begin
            for (i = 0; i < 32; i = i + 1) begin
                #1; din_a = bitof(prog[w], i, 0); din_b = bitof(prog[w], i, 1);
                @(posedge clk);
            end
        end
        repeat (200) @(posedge clk);
        check(seen_addr_a && got_a && gdata_a === 32'h55, "LSB-first stream must execute addi+sw (store 0x55 @0x10000100)");
        check(!got_b, "byte-wise MSB-first stream must NOT execute that program");
        $display("LSB-first: store seen=%0d data=%h ; MSB-first: store seen=%0d", got_a, gdata_a, got_b);
        if (errors == 0) $display("RESULT: PASS"); else $display("RESULT: FAIL");
        $finish;
    end

    // independent capture of the command phase from spi_out of cpu_a
    reg [31:0] cmdword; integer k; reg capturing; integer lowclk;
    always @(posedge clk) begin
        if (!rst_n) begin lowclk = 0; cmdword = 0; end
        else if (sel_a === 1'b0 && lowclk < 32) begin
            cmdword = {cmdword[30:0], out_a}; lowclk = lowclk + 1;
            if (lowclk == 32) begin
                $display("command word captured MSB-first: %h", cmdword);
                check(cmdword[31:24] === 8'h03, "SPI command must be 0x03 (READ)");
                check(cmdword[23:0]  === 24'h000000, "SPI start address must be 0");
            end
        end
    end
endmodule
`default_nettype wire
