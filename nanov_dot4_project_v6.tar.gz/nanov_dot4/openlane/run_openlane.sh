#!/usr/bin/env bash
# EXPLORATORY OpenLane 2 run of tt/src (SKY130, sky130_fd_sc_hd): synthesis -> floorplan -> placement -> CTS ->
# routing -> DRC/LVS checks -> GDSII.  It gives area, timing and DRC/LVS feedback early.  It is NOT the Tiny Tapeout
# submission flow: the die here is sized from cell area (FP_SIZING=relative), not the fixed TT tile with TT's pin
# template and power grid.  For a TT-compliant GDS use the GitHub Action route in openlane/README.md.
#
# Needs Linux (or Windows WSL2) with Docker:    pip install openlane
#   ./openlane/run_openlane.sh              # runs "openlane --dockerized"
#   OPENLANE_NATIVE=1 ./openlane/run_openlane.sh   # if openlane + tools are installed natively (Nix)
set -euo pipefail
cd "$(dirname "$0")"
command -v openlane >/dev/null || { echo "openlane not found - pip install openlane   (needs Docker for --dockerized)"; exit 2; }
# the SoC sources must be current copies of rtl/ (tt/src is what the flow reads)
for f in dot4_accel nanov_mmio_decoder nanov_dot4_soc; do
  cmp -s ../rtl/$f.v ../tt/src/$f.v || { echo "tt/src/$f.v differs from rtl/$f.v - run scripts/sync_tt_src.sh"; exit 3; }
done
if [ "${OPENLANE_NATIVE:-0}" = 1 ]; then openlane config.json; else openlane --dockerized config.json; fi
echo "Results: openlane/runs/<latest>/  (final/gds/*.gds, reports in 'reports' of each step, metrics.json)"
