# RTL -> GDSII for the NanoV + Dot4 design (SKY130)

**Status: NOT RUN.**  Neither OpenLane nor the Tiny Tapeout GDS action could be executed where this project was
written (no Docker daemon, no EDA tools).  Everything below is a prepared setup; nothing here proves that the design
fits a tile, meets timing, or passes DRC/LVS.

## What was verified before this step (all in `reports/`)
RTL simulation (Icarus), Verilator lint, Yosys structural checks, Yosys SKY130 area estimate (no routing/CTS), fault
injection.  Vivado xsim and implementation for the FPGA were run by the project owner, not here.

## Route A - exploratory OpenLane 2 run (early area/timing/DRC feedback, not TT-compliant)
Windows: install WSL2 (Ubuntu) + Docker Desktop with WSL integration, then inside WSL:
```
pip install openlane
cd <project>/openlane
./run_openlane.sh
```
`config.json` reads `../tt/src/*.v` (the same files Tiny Tapeout builds), clock port `clk`, 12 MHz (83.33 ns),
relative floorplan at 35 % core utilisation.  Open `runs/<latest>/final/gds/tt_um_nanov_dot4_accel.gds` in KLayout to look at the layout.
Things to read afterwards: `metrics.json` (die/cell area, setup/hold WNS, DRC/LVS error counts), the step reports for
routing DRC, Magic DRC, KLayout DRC and LVS, and antenna reports.  If the linter step stops the flow on warnings from the
unmodified upstream CPU files, say so - do not edit those files (they are byte-identical to MichaelBell/nanoV e1a405e).

Open question this run answers: the Yosys-only estimate says the shared-multiplier design needs ~26.8k um^2 of cells,
more than a 1x1 tile (~18.0k um^2), so `tiles: "2x2"` in `tt/info.yaml` is a placeholder.  Use the utilisation
reported by the real flow to choose 1x2 / 2x2 / larger.

## Route B - Tiny Tapeout submission flow (what produces the GDS that is actually fabricated)
1. Create a GitHub repository from the Tiny Tapeout SKY130 Verilog template and copy the CONTENTS of `tt/` into it
   (`info.yaml`, `src/`, `docs/`, `test/`, `.github/`).  `tt/` is already laid out that way.
2. In `info.yaml` set `author`, and rename the top module to the pattern the shuttle requires
   (`tt_um_<yourgithubuser>_...`); keep `top_module` and the module name in `src/` identical.
3. Push.  The `gds` workflow (tt-gds-action) hardens the design with OpenLane and publishes GDS, area/utilisation
   and DRC/LVS results; the `test` workflow runs `tt/test` (cocotb RTL test - already passes locally with Icarus);
   the `docs` workflow builds the datasheet from `docs/info.md`.
4. If the gds step reports that the design does not fit, increase `tiles` and push again.
5. Submit through the Tiny Tapeout website for the shuttle that is open; check its deadline, pricing, tile limits
   and template version there - these change between shuttles and were not verified here.

## Known risks specific to this design
* `multiply.v` (upstream, unmodified) instantiates the SKY130 scan flop `sky130_fd_sc_hd__sdfxtp_1` unless
  `SIMPLE_MULTIPLY` is defined.  Upstream's own Tiny Tapeout submission did the same, but whether the current flow
  accepts it was not run.
* Gate-level simulation of the hardened netlist was not run.
* The FPGA-only files (`fpga/`) are not part of the ASIC; the on-chip BRAM memory there does not exist in the chip,
  which still needs an external SPI RAM (uio[0..3]).
