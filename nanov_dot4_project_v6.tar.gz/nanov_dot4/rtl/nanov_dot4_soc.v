// NanoV (unmodified upstream CPU) + MMIO decoder + optional INT8 Dot4 accelerator.
//
// The SPI glue (negedge MISO sampling, registered select/MOSI, gated inverted
// clock) is copied from upstream nanoV_top so the external SPI waveform seen by
// a FRAM/SPI-RAM is the same as the original design.
//
// Parameters:
//   ENABLE_DOT4 : 0 -> baseline NanoV + GPIO only, 1 -> add Dot4 at 0x10000100
//   DOT4_SHARED : 1 -> shared 8x8 multiplier, 0 -> four parallel multipliers
`default_nettype none

module nanov_dot4_soc #(
    parameter ENABLE_DOT4 = 1,
    parameter DOT4_SHARED = 1
) (
    input  wire       clk,
    input  wire       rst_n,

    input  wire       spi_miso,
    output reg        spi_select,
    output wire       spi_clk_out,
    output wire       spi_clk_en,     // CPU's SPI-clock enable (lets an on-chip SPI memory work in the clk domain)
    output reg        spi_mosi,

    input  wire [2:0] gpio_in,
    output wire [7:0] gpio_out
);

    reg  buffered_spi_in;
    wire spi_data_out, spi_select_out, spi_clk_enable;
    wire [31:0] data_in;
    wire [31:0] addr_out;
    wire [31:0] data_out;
    wire is_data, is_addr, is_data_in;

    nanoV_cpu nano (
        clk,
        rst_n,
        buffered_spi_in,
        spi_select_out,
        spi_data_out,
        spi_clk_enable,
        data_in,
        addr_out,
        data_out,
        is_data,
        is_addr,
        is_data_in
    );

    wire        dot_wr_a, dot_wr_b, dot_start, dot_acc, dot_clr;
    wire [31:0] dot_a_rd, dot_b_rd, dot_result;
    wire        dot_busy, dot_done;

    // The CPU's data_in_read pulse is only needed by upstream peripherals (UART RX); unused here.
    wire _unused_ok = &{1'b0, is_data_in};

    nanov_mmio_decoder #(.ENABLE_DOT4(ENABLE_DOT4)) mmio (
        .clk(clk), .rst_n(rst_n),
        .addr_valid(is_addr), .addr(addr_out),
        .data_valid(is_data), .wdata(data_out),
        .gpio_in(gpio_in), .gpio_out(gpio_out),
        .rdata(data_in),
        .dot_wr_a(dot_wr_a), .dot_wr_b(dot_wr_b),
        .dot_start(dot_start), .dot_acc(dot_acc), .dot_clr(dot_clr),
        .dot_a_rd(dot_a_rd), .dot_b_rd(dot_b_rd), .dot_result(dot_result),
        .dot_busy(dot_busy), .dot_done(dot_done)
    );

    generate
        if (ENABLE_DOT4 != 0) begin : g_dot4
            dot4_accel #(.SHARED(DOT4_SHARED)) accel (
                .clk(clk), .rst_n(rst_n),
                .wr_a(dot_wr_a), .wr_b(dot_wr_b), .wdata(data_out),
                .start(dot_start), .acc_en(dot_acc), .clr(dot_clr),
                .a_rd(dot_a_rd), .b_rd(dot_b_rd), .result(dot_result),
                .busy(dot_busy), .done(dot_done)
            );
        end else begin : g_no_dot4
            assign dot_a_rd   = 32'd0;
            assign dot_b_rd   = 32'd0;
            assign dot_result = 32'd0;
            assign dot_busy   = 1'b0;
            assign dot_done   = 1'b0;
            wire _unused_dot  = &{1'b0, dot_wr_a, dot_wr_b, dot_start, dot_acc, dot_clr};
        end
    endgenerate

    // ---- SPI pin glue, as in upstream top.v ----
    always @(negedge clk) begin
        buffered_spi_in <= spi_miso;
    end

    always @(posedge clk) begin
        if (!rst_n)
            spi_select <= 1;
        else
            spi_select <= spi_select_out;

        spi_mosi <= spi_data_out;
    end

    assign spi_clk_out = !clk && spi_clk_enable;
    assign spi_clk_en  = spi_clk_enable;

endmodule

`default_nettype wire
