// INT8 Dot4 accelerator.
//
//   result = (acc_en ? result : 0) + sum_{i=0..3} signed(a[8i+7:8i]) * signed(b[8i+7:8i])
//
// Two micro-architectures with an identical register-level interface:
//   SHARED=1 : one 8x8 signed multiplier reused over 4 cycles (area optimised).
//              Operand registers rotate right by one byte per cycle, so no byte
//              multiplexers are needed and after 4 rotations they hold their
//              original value again (read-back of A/B is therefore stable once
//              BUSY drops).
//   SHARED=0 : four 8x8 signed multipliers and an adder tree; one compute cycle.
//
// Interface rules (both variants):
//   * wr_a / wr_b / start / clr are ignored while busy is high.
//   * start (1-cycle pulse) raises busy, clears done, and clears the accumulator
//     unless acc_en is set.  Compute latency after the start edge:
//     SHARED=1 -> 4 cycles, SHARED=0 -> 1 cycle.  done rises when busy falls.
//   * clr clears the accumulator and done.
//   * result is a 32-bit two's-complement accumulator and wraps on overflow.
`default_nettype none

module dot4_accel #(
    parameter SHARED = 1
) (
    input  wire        clk,
    input  wire        rst_n,

    input  wire        wr_a,
    input  wire        wr_b,
    input  wire [31:0] wdata,
    input  wire        start,
    input  wire        acc_en,
    input  wire        clr,

    output wire [31:0] a_rd,
    output wire [31:0] b_rd,
    output wire [31:0] result,
    output wire        busy,
    output wire        done
);

    reg [31:0] a_r, b_r;
    reg [31:0] acc;
    reg        busy_r, done_r;

    assign a_rd   = a_r;
    assign b_rd   = b_r;
    assign result = acc;
    assign busy   = busy_r;
    assign done   = done_r;

    generate
        if (SHARED != 0) begin : g_shared
            reg [1:0] cnt;

            wire signed [7:0]  ma   = a_r[7:0];
            wire signed [7:0]  mb   = b_r[7:0];
            wire signed [15:0] prod = ma * mb;

            always @(posedge clk) begin
                if (!rst_n) begin
                    a_r    <= 32'd0;
                    b_r    <= 32'd0;
                    acc    <= 32'd0;
                    busy_r <= 1'b0;
                    done_r <= 1'b0;
                    cnt    <= 2'd0;
                end else if (busy_r) begin
                    acc <= acc + {{16{prod[15]}}, prod};
                    a_r <= {a_r[7:0], a_r[31:8]};
                    b_r <= {b_r[7:0], b_r[31:8]};
                    cnt <= cnt + 2'd1;
                    if (cnt == 2'd3) begin
                        busy_r <= 1'b0;
                        done_r <= 1'b1;
                    end
                end else begin
                    if (wr_a) a_r <= wdata;
                    if (wr_b) b_r <= wdata;
                    if (clr) begin
                        acc    <= 32'd0;
                        done_r <= 1'b0;
                    end
                    if (start) begin
                        busy_r <= 1'b1;
                        done_r <= 1'b0;
                        cnt    <= 2'd0;
                        if (!acc_en) acc <= 32'd0;
                    end
                end
            end
        end else begin : g_parallel
            wire signed [7:0] a0 = a_r[7:0],   b0 = b_r[7:0];
            wire signed [7:0] a1 = a_r[15:8],  b1 = b_r[15:8];
            wire signed [7:0] a2 = a_r[23:16], b2 = b_r[23:16];
            wire signed [7:0] a3 = a_r[31:24], b3 = b_r[31:24];

            wire signed [15:0] p0 = a0 * b0;
            wire signed [15:0] p1 = a1 * b1;
            wire signed [15:0] p2 = a2 * b2;
            wire signed [15:0] p3 = a3 * b3;

            wire signed [31:0] sum =
                  {{16{p0[15]}}, p0} + {{16{p1[15]}}, p1}
                + {{16{p2[15]}}, p2} + {{16{p3[15]}}, p3};

            always @(posedge clk) begin
                if (!rst_n) begin
                    a_r    <= 32'd0;
                    b_r    <= 32'd0;
                    acc    <= 32'd0;
                    busy_r <= 1'b0;
                    done_r <= 1'b0;
                end else if (busy_r) begin
                    acc    <= acc + sum;
                    busy_r <= 1'b0;
                    done_r <= 1'b1;
                end else begin
                    if (wr_a) a_r <= wdata;
                    if (wr_b) b_r <= wdata;
                    if (clr) begin
                        acc    <= 32'd0;
                        done_r <= 1'b0;
                    end
                    if (start) begin
                        busy_r <= 1'b1;
                        done_r <= 1'b0;
                        if (!acc_en) acc <= 32'd0;
                    end
                end
            end
        end
    endgenerate

endmodule

`default_nettype wire
