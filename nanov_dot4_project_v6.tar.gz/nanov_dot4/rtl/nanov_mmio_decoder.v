// MMIO address decoder / register interface for NanoV.
//
// Reproduces the peripheral protocol of upstream nanoV_top (top.v @ e1a405e):
//   * store_addr_out pulses with the peripheral address on addr_out; the
//     decoder registers which peripheral that address selects.
//   * store_data_out pulses with the value in data_out; the write goes to the
//     peripheral selected by the *registered* selection (so a new address
//     arriving in the same clock as the previous store's data does not
//     disturb that store).
//   * Loads read ext_data_in bit-serially during the load instruction, so
//     rdata is a combinational function of the registered selection only.
//
// Address map (identical upstream GPIO addresses, plus new Dot4 block):
//   0x10000000  GPIO_OUT   W: bits[7:0] drive output pins; R: readback
//   0x10000004  GPIO_IN    R: {29'b0, gpio_in[2:0]}   (upstream: buttons 3..1)
//   0x10000100  DOT_A      W/R: 4 packed signed int8 operands
//   0x10000104  DOT_B      W/R: 4 packed signed int8 operands
//   0x10000108  DOT_CTRL   W: bit0 START, bit1 ACC (accumulate), bit2 CLR
//                          R: bit0 BUSY, bit1 DONE
//   0x1000010C  DOT_RESULT R: 32-bit signed accumulator
// Any other address: writes ignored, reads return 0.  (Upstream LED/UART/MUSIC
// peripherals are board specific to the iCEFUN and are not part of this design.)
`default_nettype none

module nanov_mmio_decoder #(
    parameter ENABLE_DOT4 = 1
) (
    input  wire        clk,
    input  wire        rst_n,

    input  wire        addr_valid,   // nanoV_cpu.store_addr_out
    input  wire [31:0] addr,         // nanoV_cpu.addr_out
    input  wire        data_valid,   // nanoV_cpu.store_data_out
    input  wire [31:0] wdata,        // nanoV_cpu.data_out

    input  wire [2:0]  gpio_in,
    output reg  [7:0]  gpio_out,

    output wire [31:0] rdata,        // -> nanoV_cpu.ext_data_in

    output wire        dot_wr_a,
    output wire        dot_wr_b,
    output wire        dot_start,
    output wire        dot_acc,
    output wire        dot_clr,
    input  wire [31:0] dot_a_rd,
    input  wire [31:0] dot_b_rd,
    input  wire [31:0] dot_result,
    input  wire        dot_busy,
    input  wire        dot_done
);

    localparam [3:0] PERI_NONE     = 4'd0;
    localparam [3:0] PERI_GPIO_OUT = 4'd2;   // same ids as upstream top.v
    localparam [3:0] PERI_GPIO_IN  = 4'd3;
    localparam [3:0] PERI_DOT_A    = 4'd8;
    localparam [3:0] PERI_DOT_B    = 4'd9;
    localparam [3:0] PERI_DOT_CTRL = 4'd10;
    localparam [3:0] PERI_DOT_RES  = 4'd11;

    reg [3:0] sel;

    always @(posedge clk) begin
        if (!rst_n) begin
            sel <= PERI_NONE;
        end else if (addr_valid) begin
            if      (addr == 32'h10000000) sel <= PERI_GPIO_OUT;
            else if (addr == 32'h10000004) sel <= PERI_GPIO_IN;
            else if (ENABLE_DOT4 != 0 && addr == 32'h10000100) sel <= PERI_DOT_A;
            else if (ENABLE_DOT4 != 0 && addr == 32'h10000104) sel <= PERI_DOT_B;
            else if (ENABLE_DOT4 != 0 && addr == 32'h10000108) sel <= PERI_DOT_CTRL;
            else if (ENABLE_DOT4 != 0 && addr == 32'h1000010c) sel <= PERI_DOT_RES;
            else                                               sel <= PERI_NONE;
        end
    end

    always @(posedge clk) begin
        if (!rst_n)
            gpio_out <= 8'd0;
        else if (data_valid && sel == PERI_GPIO_OUT)
            gpio_out <= wdata[7:0];
    end

    wire wr_ctrl = data_valid && sel == PERI_DOT_CTRL;

    assign dot_wr_a  = (ENABLE_DOT4 != 0) && data_valid && sel == PERI_DOT_A;
    assign dot_wr_b  = (ENABLE_DOT4 != 0) && data_valid && sel == PERI_DOT_B;
    assign dot_start = (ENABLE_DOT4 != 0) && wr_ctrl && wdata[0];
    assign dot_acc   = wdata[1];
    assign dot_clr   = (ENABLE_DOT4 != 0) && wr_ctrl && wdata[2];

    reg [31:0] rd;
    always @(*) begin
        case (sel)
            PERI_GPIO_OUT: rd = {24'd0, gpio_out};
            PERI_GPIO_IN:  rd = {29'd0, gpio_in};
            PERI_DOT_A:    rd = (ENABLE_DOT4 != 0) ? dot_a_rd   : 32'd0;
            PERI_DOT_B:    rd = (ENABLE_DOT4 != 0) ? dot_b_rd   : 32'd0;
            PERI_DOT_CTRL: rd = (ENABLE_DOT4 != 0) ? {30'd0, dot_done, dot_busy} : 32'd0;
            PERI_DOT_RES:  rd = (ENABLE_DOT4 != 0) ? dot_result : 32'd0;
            default:       rd = 32'd0;
        endcase
    end
    assign rdata = rd;

    // Only the low byte of a GPIO write and bits [2:0] of a CTRL write are decoded.
    wire _unused_ok = &{1'b0, wdata[31:8]};

endmodule

`default_nettype wire
