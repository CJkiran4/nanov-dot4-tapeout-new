#!/usr/bin/env bash
# Structural checks with Yosys: no unresolved modules, no multiple drivers / combinational loops (check -assert),
# and no inferred latches, for each configuration.  Also a Xilinx-7 mapped synthesis of the ZedBoard wrapper as a
# synthesizability smoke test (NOT a substitute for Vivado: different mapper, no timing, no implementation).
set -uo pipefail
cd "$(dirname "$0")/.."
UP="rtl/upstream/alu.v rtl/upstream/core.v rtl/upstream/cpu.v rtl/upstream/register.v rtl/upstream/shift.v rtl/upstream/multiply.v"
NEW="rtl/dot4_accel.v rtl/nanov_mmio_decoder.v rtl/nanov_dot4_soc.v"
: > reports/yosys_checks.txt; rc=0
one() { # label en shared
  local log; log=$(yosys -p "read_verilog -sv -DSIMPLE_MULTIPLY $UP $NEW; chparam -set ENABLE_DOT4 $2 -set DOT4_SHARED $3 nanov_dot4_soc; hierarchy -check -top nanov_dot4_soc; proc; opt_clean; check -assert; synth -flatten -top nanov_dot4_soc; tee -o /dev/stdout stat" 2>&1)
  local st=$?
  local lat; lat=$(printf '%s\n' "$log" | grep -c -E '\$_DLATCH|\$dlatch|\$_DLATCHSR' || true)
  if printf '%s\n' "$log" | grep -q -E '^ERROR' || [ "$lat" -ne 0 ]; then echo "$1: FAIL (errors or $lat latch cells)"; printf '%s\n' "$log" | grep -E '^ERROR' | head -3; rc=1
  else echo "$1: PASS (hierarchy -check, check -assert, 0 latches)"; fi
  printf '== %s\n%s\n' "$1" "$(printf '%s\n' "$log" | grep -E 'Warning|ERROR|Number of cells' | head -20)" >> reports/yosys_checks.txt
}
one "ENABLE_DOT4=1 SHARED=1" 1 1
one "ENABLE_DOT4=1 SHARED=0" 1 0
one "ENABLE_DOT4=0"          0 1
# yosys' Xilinx library (cells_sim/cells_xtra) provides BUFG and MMCME2_BASE as primitives, so no stub file is read here.
x=$(yosys -p "read_verilog -sv -DSIMPLE_MULTIPLY $UP $NEW fpga/zedboard_nanov_dot4_top.v fpga/spi_mem_bram.v fpga/board_spi_mem.v; synth_xilinx -top zedboard_nanov_dot4_top -flatten" 2>&1)
printf '%s\n' "$x" > reports/yosys_xilinx_full.log
cells=$(printf '%s\n' "$x" | grep -E '^ +(LUT[1-6]|FDRE|FDCE|FDPE|FDSE|CARRY4|RAMB18E1|RAMB36E1|RAM32M|RAM64M|RAM32X1D|RAM64X1D|DSP48E1) ' | awk '{printf "%s=%s ", $1,$2}')
if printf '%s\n' "$x" | grep -q -E 'ERROR'; then echo "zedboard wrapper synth_xilinx: FAIL"; printf '%s\n' "$x" | grep ERROR | head -3; rc=1
elif ! printf '%s\n' "$cells" | grep -q -E 'RAMB(18|36)E1'; then echo "zedboard wrapper synth_xilinx: FAIL (on-chip memory was not mapped to block RAM) $cells"; rc=1
else echo "zedboard wrapper synth_xilinx (stubbed MMCM, yosys mapper): PASS  $cells"; fi
exit $rc
