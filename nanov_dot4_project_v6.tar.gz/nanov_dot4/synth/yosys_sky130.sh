#!/usr/bin/env bash
# Generic Yosys + abc mapping to real sky130_fd_sc_hd (tt_025C_1v80) cells.
# This is an AREA ESTIMATE of mapped standard cells only - it is NOT OpenLane/TT
# place-and-route, includes no clock tree / fill / routing, and says nothing about
# whether a design fits a Tiny Tapeout tile.
# usage: synth/yosys_sky130.sh   -> writes reports/synth_sky130_<variant>.txt and a summary table
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
RAWLIB="$ROOT/refs/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib"
LIB="$ROOT/refs/pdk/sky130_hd_tt_filtered.lib"
[ -f "$RAWLIB" ] || { echo "missing $RAWLIB (fetched from OpenROAD-flow-scripts platforms/sky130hd/lib)"; exit 2; }
[ -f "$LIB" ] || python3 "$ROOT/synth/filter_lib.py" "$RAWLIB" "$LIB"
UP=rtl/upstream
SRC="$UP/alu.v $UP/core.v $UP/cpu.v $UP/register.v $UP/shift.v $UP/multiply.v rtl/dot4_accel.v rtl/nanov_mmio_decoder.v rtl/nanov_dot4_soc.v"
mkdir -p reports
run() { # name enable shared
  local name=$1 en=$2 sh=$3
  yosys -q -l "reports/synth_sky130_$name.log" -p "
    read_liberty -lib $LIB
    read_verilog -sv $SRC
    chparam -set ENABLE_DOT4 $en -set DOT4_SHARED $sh nanov_dot4_soc
    hierarchy -check -top nanov_dot4_soc
    synth -flatten -top nanov_dot4_soc
    dfflibmap -liberty $LIB
    abc -liberty $LIB
    opt_clean -purge
    tee -o reports/synth_sky130_$name.txt stat -liberty $LIB
  " >/dev/null
  python3 - "reports/synth_sky130_$name.txt" "$name" <<'PY'
import re,sys
t=open(sys.argv[1]).read()
area=re.search(r'Chip area for (?:top )?module.*?:\s*([\d.]+)',t)
cells=re.search(r'^\s*(\d+)\s+[\d.]*\s*cells',t,re.M) or re.search(r'Number of cells:?\s+(\d+)',t)
ff=sum(int(m.group(2)) for m in re.finditer(r'^\s*sky130_fd_sc_hd__((?:s?e?df)\w*)\s+(\d+)\s*$',t,re.M))
print(f"{sys.argv[2]:<22} area_um2={area.group(1) if area else '?':>10}  cells={cells.group(1) if cells else '?':>6}  flops={ff}  lpflow_cells={t.count('lpflow')}")
PY
}
{
 run baseline_no_dot4 0 1
 run dot4_shared      1 1
 run dot4_parallel    1 0
} | tee reports/synth_sky130_summary.txt
