#!/usr/bin/env python3
"""Remove dont-use cells (lpflow_*, probe*) from a liberty file by brace matching."""
import re, sys
src, dst = sys.argv[1:3]
t = open(src).read()
out, i, removed = [], 0, 0
pat = re.compile(r'\n\s*cell\s*\(\s*"?(sky130_fd_sc_hd__(?:lpflow_\w+|probe_p_8|probec_p_8))"?\s*\)\s*\{')
while True:
    m = pat.search(t, i)
    if not m:
        out.append(t[i:]); break
    out.append(t[i:m.start()])
    depth, j = 1, m.end()
    while depth:
        c = t[j]
        depth += (c == '{') - (c == '}')
        j += 1
    i, removed = j, removed + 1
open(dst, 'w').write(''.join(out))
print(f"removed {removed} cells -> {dst}")
